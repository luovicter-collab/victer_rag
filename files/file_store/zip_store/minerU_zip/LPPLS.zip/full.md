# Identifying price bubbles in global carbon markets: Evidence from the SADF test, GSADF test and LPPLS method

![](images/ee99497ffeccf16b644959166682bd1e266658fd5abadf93a377e6c597f962b4.jpg)

Wenyang Huang a,1, Yizhi Wang b,\*,2

a College of Economics and Management, China Agricultural University   
<sup>b</sup> Cardiff Business School, Cardiff University, United Kingdom

# ARTICLEINFO

Keywords:

Carbon market instability

Emissions trading schemes (ETS)

Monetary policy implications

Price bubble detection

SADF/GSADF/LPPLS

# ABSTRACT

Amid growing climate concerns, Emissions Trading Schemes (ETS) serve as key mechanisms for reducing greenhouse gas emissions through market forces. This study delves into the phenomenon of price bubbles within six major ETSs globally: the European Union Emissions Trading Scheme (EU ETS), the New Zealand Emissions Trading Scheme (NZ ETS), the California-Québec Emissions Trading Scheme (CQ ETS), the South Korea Emissions Trading Schemes (K-ETS), the China Emissions Trading Scheme (C-ETS), and the United Kingdom Emissions Trading Schemes (UK ETS). Employing the sup augmented Dickey-Fuller (SADF) test, generalized sup ADF (GSADF) test, and log-periodic power law singularity (LPPLS) model, our analysis aims to uncover the dynamics and implications of these bubbles. Our findings reveal varied patterns of price bubbles across the schemes, with the EU ETS showing the highest frequency and the NZ ETS exhibiting the longest durations. The period of 2021 and 2022 marked a significant increase in bubble occurrences across all ETSs, suggesting the influence of post-COVID-19 economic recovery and geopolitical tensions on market stability. These bubbles are attributed to factors including carbon market policies, macroeconomic conditions, energy price fluctuations, and market uncertainties. The study offers valuable insights for compliance firms, policymakers, and investors on navigating carbon market volatility. Understanding bubble dynamics can aid in formulating more effective emission reduction strategies, carbon pricing policies, and investment decisions. This research underscores the importance of integrating monetary policy considerations with environmental objectives within ETS frameworks, paving the way for future research on predictive bubble detection and the development of robust carbon market regulations.

# 1. Introduction

The greenhouse effect remains a paramount concern for global environmental sustainability, with carbon dioxide $(\mathrm{CO}_{2})$ emissions from human activities being a principal contributor (Brander and Davis, 2012). The Royal Society reports that in 2019, atmospheric $\mathrm{CO}_{2}$ levels surpassed 411 ppm (ppm), reaching a zenith not observed in nearly 800,000 years (De La Vega et al., 2020). Such unprecedented concentrations of $\mathrm{CO}_{2}$ pose significant and potentially irreversible impacts on Earth's ecosystems. Manifestations of these impacts include the melting of polar glaciers (Titus, 1986), ocean acidification (Hofmann and Schellnhuber, 2010), escalated frequencies of extreme weather events (Gordon et al., 1992), and the accelerated transmission and proliferation of epidemic diseases, thereby posing direct threats to human health

# (Sachan and Singh, 2010).

To mitigate the intensification of the greenhouse effect, the Kyoto Protocol was ratified in 1997 in Kyoto, Japan, aiming to stabilize atmospheric levels of greenhouse gases at a level that would prevent catastrophic climate change impacts on humanity. The protocol mandates that developed countries commence reducing their carbon emissions starting in 2005, with developing countries following suit in 2012 (Bohringer, 2003). Utilizing market mechanisms as a strategic approach to curbing greenhouse gas emissions, the protocol establishes the concept of carbon dioxide emission rights trading, essentially treating the right to emit carbon dioxide as a tradable commodity. This has given rise to the Carbon Emission Trading System (ETS), responsible for overseeing carbon trading activities (Oberthur and Ott, 1999).

In response to the global imperative for emissions reduction, various

nations have sequentially initiated their carbon emissions trading systems. Notable examples include the European Union Emissions Trading Scheme (EU ETS) (Huang et al., 2023), the Japan Voluntary Emissions Trading Scheme (JV ETS) (Mochizuki, 2011), the Korea Emissions Trading Schemes (K-ETS) (Hyun and Oh, 2015), the New Zealand Emission Trading Scheme (NZ ETS) (Leining et al., 2020), the Regional Greenhouse Gas Initiative (RGGI) (Yan, 2021), the China Emission Trading Schemes (C-ETS) (Huang et al., 2022b), the Western Climate Initiative (WCI) (Houle et al., 2015), and the United Kingdom Emissions Trading Schemes (UK ETS) (Wei et al., 2023), among others. According to the World Bank, there are currently more than 30 ETSs operating globally, which are expected to cover $8.91\mathrm{GtCO_2}$ in 2023, thus accounting for $17.64\%$ of global GHG emissions.

A price bubble is typically characterized as a period during which an asset's price significantly diverges from its intrinsic value, representing an unsustainable deviation (Diba and Grossman, 1988). This phenomenon manifests when an asset's price experiences a rapid escalation over a short duration, followed by a precipitous decline. The fluctuation and uncertainty associated with carbon prices present a notable challenge in the design of carbon market mechanisms. Given that the emissions trading system serves as a principal instrument of climate governance, aimed at achieving the most cost-efficient emission reduction outcomes through market-based approaches (Wei et al., 2022), the stability of carbon prices is of paramount concern. Empirical research indicates that several factors contribute to carbon price volatility and the formation of bubbles. These include variations in energy prices (Creti et al., 2012), the incidence of extreme weather events (Mansanet-Bataller et al., 2007), the public disclosure of carbon emission policies (Lu et al., 2023), shifts in macroeconomic conditions (Koch et al., 2014), risks associated with market operations (Song et al., 2018), the level of industrial development (Mansanet-Bataller et al., 2010), and the structure of corporate governance and incentives at various levels (Riedl, 2022). These elements collectively influence carbon market dynamics, potentially leading to the emergence of price bubbles.

The presence of price bubbles in the Emissions Trading System (ETS) adversely impacts the achievement of emission reduction targets and the management of market risks, with significant consequences across three main sectors. First, for regulated enterprises, the emergence of carbon price bubbles within the ETS escalates the costs associated with emission reductions. Consequently, the distorted carbon prices hinder these enterprises' ability to achieve emission reduction targets cost-effectively (Wei et al., 2022). Second, for governments, the carbon price within the ETS serves as a critical indicator for the allocation of carbon emission quotas. A bubble in the carbon price impedes its ability to accurately reflect the true marginal abatement costs, thereby disrupting the decision-making processes of policymakers and altering public expectations, potentially leading to inappropriate policy formulation (Xu and Salem, 2021). Third, for investors, the volatility associated with ETS carbon prices exerts detrimental spillover effects on the stock returns of energy-intensive industries. This volatility undermines investors' portfolio strategies and complicates risk management efforts (Mayer, 2012). Collectively, these impacts underscore the need for robust mechanisms to detect and mitigate the effects of carbon price bubbles within the ETS framework, ensuring the system's effectiveness in promoting environmental sustainability and economic stability.

The detection of price bubbles has emerged as a significant area of interest within econometrics, driven by the profound implications of these phenomena. The asset pricing model introduced by Lucas (1978) lays the foundational framework for analyzing rational bubbles, which occur when asset prices significantly diverge from their intrinsic values. Subsequent advancements in bubble detection methodologies have led to the development of various approaches, including variance bounds tests (LeRoy and Porter, 1981), West's two-step tests (West, 1987), the momentum threshold autoregressive model (Engle and Granger, 1987), integration or cointegration-based tests (Diba and Grossman, 1987), intrinsic bubbles tests (Froot, 1991), and the Kalman filter test (Wu,

1997). To address potential issues of pseudo-regression inherent in these methods and enhance detection efficiency, Phillips et al. (2011) introduced the sup augmented Dickey-Fuller (SADF) test. This test demonstrates high estimation efficiency for identifying singular bubble events within a complete sample period, exemplified by the U.S. housing price bubble in the early 21st century. Addressing the limitations of the SADF test in detecting multiple bubbles, Phillips et al. (2015) subsequently developed the generalized sup ADF (GSADF) test. Offering increased flexibility in the detection window and encompassing a broader subsample of data, the GSADF test effectively captures multiple instances of explosive bubble behavior across the entire sample. The backward SADF statistic (BSADF), associated with the GSADF, facilitates an efficient mechanism for determining the quantity of bubbles, including their initiation and termination points.

Numerous studies have explored the phenomena of price bubbles within global carbon markets utilizing the SADF and GSADF tests. For instance, Creti and Joëts (2017) pioneered the application of SADF and GSADF to investigate bubbles in front-month contract prices of the European Union Emissions Trading Scheme (EU ETS) over the period from 2005 to 2014. They employed the wild bootstrap procedure, as proposed by Gonçalves and Kilian (2004), to mitigate heteroskedasticity in carbon price data. Their empirical findings revealed multiple price bubbles, which, while not solely explicable by fundamental behaviors, appeared to correlate with announcements in energy and environmental policies. Xu and Salem (2021) conducted the inaugural bubble test on carbon prices within eight regional carbon emissions trading schemes in China, including Beijing, Shanghai, Guangdong, Hubei, Shenzhen, Tianjin, Chongqing, and Fujian. Their analysis identified three bubbles in the Guangdong pilot, two in the Tianjin pilot, and one in the Hubei pilot, attributing these phenomena to nascent market mechanisms and policy implementations. Wei et al. (2022) examined the presence of price bubbles from the inception date to August 31, 2019, in four ETSs within the EU, New Zealand, South Korea, and Shenzhen, China, through SADF and GSADF. Their research scrutinized the timing, frequency, intensity, and origins of the bubbles' formation and cessation in each market. They discovered that bubbles in the EU, New Zealand, and South Korea's ETSs tended to persist for extended periods, often exceeding five days. Conversely, the Shenzhen ETS experienced shorter-lived bubbles, with durations not surpassing three days. The EU ETS was particularly prone to significant price bubbles, attributed to its sensitivity to industrial shifts and policy modifications in participant countries. Lastly, Lu et al. (2023) applied SADF and GSADF to detect bubbles in the carbon price within Beijing's carbon market from January 2014 to April 2018. Their findings highlighted multiple bubbles closely associated with the environmental policies promulgated by the Chinese government. Furthermore, they noted that carbon price volatility in Beijing's ETS exceeded that of the EU ETS, with the two markets exhibiting a negative correlation.

Although the SADF and GSADF tests offer retrospective analyses of bubble events, their utility is limited in predicting future bubble burst points or in elucidating the intricate mechanisms of bubble formation (Yao and Li, 2021). In response, recent research has increasingly employed the log-periodic power law singularity (LPPLS) model for the diagnosis and foresight of bubble occurrences and crashes (Geraskin and Fantazzini, 2020). The LPPLS model's capacity to anticipate both positive and negative bubble trends and their imminent collapses presents a valuable tool in constraining bubble magnitudes and thereby mitigating the resultant damage (Yao and Li, 2021). According to the LPPLS theory, asset bubbles emerge through mimicry among traders, fostering a herd behavior propelled by positive feedback, with the eventual crashes resulting from underlying market dynamics. This phenomenon is characterized by logarithmic periodic oscillations in price trajectories, which intensify until reaching a pivotal juncture where a burst becomes inevitable (Johansen and Sornette, 2001). The LPPLS model has demonstrated efficacy in identifying and forecasting bubbles across various financial assets, including the S&P 500 Index (al., 2016), the CSI 300

Index (Li, 2017), Bitcoin (Wheatley et al., 2019), and the Dow Jones Index (Grobys, 2023), among others. However, to our knowledge, the application of LPPLS in detecting and projecting carbon price bubbles remains unexplored.

The aim of this research is to investigate the presence and longevity of price bubbles within the carbon pricing mechanisms of six pivotal global Emissions Trading Schemes (ETSs), and to further assess their implications for monetary policy and the broader financial stability of energy markets. The six Emissions Trading Schemes (ETSs) selected for this study are the European Union Emissions Trading Scheme (EU ETS), the New Zealand Emissions Trading Scheme (NZ ETS), the California-Quebec Emissions Trading Scheme (CQ ETS), the South Korea Emissions Trading Schemes (K-ETS), the China Emissions Trading Scheme (C-ETS), and the United Kingdom Emissions Trading Schemes (UK ETS).

The contributions of this study are pivotal, intersecting the realms of academic research and practical application within the context of monetary policy and energy/climate investments, specifically through the lens of ETSs on a global scale. Firstly, by undertaking a comprehensive analysis of carbon price bubbles in six key global ETSs, this research fills a critical gap in existing literature, offering insights that bridge economic theory with the operational realities of carbon markets. The elucidation of bubble dynamics within these ETSs sheds light on the interplay between market mechanisms and environmental policy efficacy. Moreover, the findings provide empirical evidence that can guide the calibration of monetary policies to better support the objectives of ETSs. By understanding the factors that contribute to market stability, monetary authorities can tailor financial instruments and interest rate policies to foster environments conducive to sustainable energy investments, enhancing the resilience of carbon markets against speculative disruptions. Secondly, the adoption of the LPPLS model marks a significant advancement in predicting market behaviors within carbon trading systems. This novel approach transcends the reactive nature of traditional ex-post analysis, offering a predictive tool that can inform both market participants and policymakers. By identifying potential price bubbles before they burst, the LPPLS model enables a preemptive policy response, aligning monetary interventions with market needs to stabilize energy investments. Such forward-looking capabilities are essential for integrating monetary policy frameworks with climate goals, ensuring that energy investments are not only protected from speculative volatility but also aligned with long-term sustainability targets.

The structure of this study is organized as follows: Section 2 offers a foundational overview of globally significant Emissions Trading Systems (ETSs). Section 3 delineates the research methodology and data utilized. Section 4 examines the empirical results. Section 5 concludes the study with a summary of findings and policy recommendations.

# 2. Global major emission trading schemes

To encourage businesses to adopt low-carbon facilities and production methods, thereby achieving efficient carbon emission reductions, an increasing number of national and local governments are implementing carbon pricing strategies through the initiation, acceleration, or enhancement of Emissions Trading Systems (ETS) construction (Wei et al., 2022). This study selects six representative ETSs from the European Union, South Korea, New Zealand, China, and the United Kingdom to identify and investigate price bubbles in carbon markets. This section will provide a concise overview of the development history of these six ETSs.

# 2.1. European Union emission trading scheme (EU ETS)

Launched in 2005, the EU ETS is both the earliest established and the largest carbon market globally, currently encompassing emissions from electricity, industry, and flights within the European Economic Area (EEA), accounting for approximately $45\%$ of the EU's total emissions. The EU ETS is distinguished by its decentralized management, a

synchronized development model, and a robust emissions monitoring, reporting, and verification (MRV) system (Huang et al., 2024). This framework serves as a valuable reference for other carbon markets. The EU ETS's primary objective is to generate price signals via allowance trading to steer the emission reduction efforts of regulated entities and foster the development and adoption of low-carbon technologies (Viteva et al., 2014). Since its inception, the EU ETS has been a cornerstone policy of the European Commission, aiding member states in achieving the emission reduction targets stipulated by the Kyoto Protocol (Tan and Wang, 2017).

To date, the EU ETS has progressed through three phases and has commenced Phase IV. Phase I (2005-2007) served as a pilot, testing the carbon market's price formation and experimenting with mechanisms for later phases. During this phase, carbon allowances were allocated almost entirely free of charge based on requests from each participating country through a bottom-up National Allocation Plan (NAP), leading to a significant surplus of allowances and a structural collapse by the phase's end, with carbon allowance prices nearing zero. Phase II (2008-2012), a transitional phase, aimed for an $8\%$ reduction in carbon emissions by 2012 relative to 1990 levels, and saw rapid growth in market transactions and expanded coverage across countries and sectors. Nevertheless, the allocation of carbon allowances remained predominantly under NAPs, with no more than $10\%$ distributed via auctions (Huang et al., 2022a).

Phase III (2013-2020) marked the reform phase, aimed at ensuring Europe met its objective of reducing greenhouse gas (GHG) emissions by $20\%$ by 2020, relative to 1990 levels (Creti et al., 2012). During this period, several key initiatives were introduced. First, the carbon allowance allocation mechanism, previously centered on the bottom-up National Allocation Plan (NAP), was superseded by a top-down allocation mechanism. This approach, termed the National Implementation Measure (NIM), involved the European Union uniformly setting carbon emission allowances and distributing them to member states (Huang et al., 2022a). Second, there was a gradual shift from the original free allocation mode to an auction format, with the proportion of allowances auctioned set to not less than $30\%$ , increasing to $70\%$ by 2020 (Huang et al., 2024). Third, a Market Stabilization Reserve (MSR) mechanism was established to address the issue of excess quota supply. Fourth, the credit offset mechanism was stringently restricted, mandating that projects used for carbon offsets originate exclusively from the least developed countries.

Phase IV (2021-2030), recognized as the maturity phase, targets a $40\%$ reduction in GHG emissions compared to 1990 levels (Zaklan et al., 2021). In this phase, the EU mandates a $2.2\%$ annual reduction in total allowances, with the discontinuation of carbon credit offsets. For sectors at low risk of carbon leakage, it is anticipated that free allocations will be phased out post-2026. Concurrently, low-carbon financing funds are to be established for carbon-intensive industrial sectors and the power sector (Perino, 2018).

# 2.2. New Zealand emission trading scheme (NZ ETS)

After a decade-long debate within the Labor administration regarding the most effective method to price carbon in New Zealand, the country enacted the Climate Change Response (Emissions Trading) Amendment Act and established the NZ ETS in 2008. The NZ ETS stands as the first emissions trading scheme intended to encompass all economic sectors and the six principal greenhouse gases. Its primary objective is to assist New Zealand in fulfilling its international climate change commitments and to reduce the nation's carbon emissions to below typical levels at the lowest feasible cost (Bullock, 2012). Initially, the NZ ETS functioned as a nested system under the Kyoto Protocol until June 2015, when it transitioned to a domestic carbon trading system. The New Zealand government has since implemented legislative reforms to enhance the carbon market's design and operation, ensuring alignment with the country's national emissions reduction pledges. As of

November 2019, the system accounts for approximately $52\%$ of New Zealand's total emissions (Leining et al., 2020).

Agriculture is a significant contributor to both New Zealand's GDP and its greenhouse gas emissions, with the agricultural sector alone accounting for $49\%$ of the country's emissions, a stark contrast to the $12\%$ typically observed in other developed nations (Ranson and Stavins, 2016). Another distinctive aspect of New Zealand is its forestry sector's capacity to serve as a substantial carbon sink. Consequently, the NZ ETS has introduced a pioneering ETS design that mirrors New Zealand's unique emissions profile, economic structure, regulatory culture, and early experiences with environmental markets. This innovative design encompasses all economic sectors and major greenhouse gases (GHGs), making New Zealand the only country with plans to include both the agriculture and forestry sectors within its ETS. It features an upstream point of obligation for the energy sector, enforcing emission reduction requirements at the point of fuel production or importation, while offering major downstream users the option to opt in (Leining et al., 2020). Furthermore, it permits the unlimited importation and use of overseas carbon credits to meet obligations (Ranson and Stavins, 2016), caps the price of carbon emissions at NZ$25 (Bullock, 2012), allocates zero free emissions for energy sector participants, and employs a self-assessment-based monitoring, reporting, and verification system, supplemented by audits and penalties.

# 2.3. California-Quebec emission trading scheme (CQ ETS)

The California Air Resources Board $(\mathrm{CARB})^{3}$ was established in 2012 to ensure that California achieves its greenhouse gas (GHG) reduction targets in a cost-effective manner. Employing a cap-and-trade system, CARB sets an annually decreasing emissions cap, thereby generating a stable and consistent carbon pricing signal that encourages actions to reduce GHG emissions. CARB's scope encompasses the industrial sector and most fossil fuel combustion, mandating compliance with the cap-and-trade program for sources emitting more than 25,000 metric tons of $\mathrm{CO}_{2}$ equivalent per year. This includes the power generation sector and significant stationary sources such as refineries, cement production facilities, oil and gas production sites, glass manufacturing plants, and food processing factories, which collectively account for approximately $80\%$ of the state's total emissions (Wang et al., 2022a, 2022b).

In January 2014, the California carbon market in the United States was linked with the Quebec carbon market in Canada, leading to the conduct of the first joint auction in November 2014. Since that time, carbon allowance auctions have been conducted quarterly, with four auctions each year, resulting in a total of 45 auctions by the end of 2023. The carbon market in Quebec, Canada, encompasses the power, industrial, construction, and transportation sectors, covering approximately $77\%$ of the carbon emissions in its region. Although California and Quebec operate within different trading systems, they share similar emission reduction targets, sectors, and scopes of emission control, quota auction rules, and price control mechanisms. This high degree of compatibility has facilitated the integration of their carbon markets, enabling both parties to access a broader range of emission reduction options and opportunities. This collaboration aims to achieve a mutually beneficial outcome.

# 2.4. South Korea emission trading schemes (K-ETS)

South Korea ranks as the world's eighth-largest energy consumer and sixth-largest coal consumer. In response to its responsibility to reduce carbon emissions, the Korean government introduced the "low carbon-green growth" national carbon emission reduction policy in 2009. This policy aimed to decrease national $\mathrm{CO}_{2}$ emissions to $30\%$ below business

as-usual (BAU) levels by 2020 (Hyun and Oh, 2015). Under this policy framework, the Korean government also established the "Management of Targets for GHGs and Energy" system in 2012. This system was designed to set, manage, and support GHG emission reduction targets for the industry and power plant sectors. As a tangible measure for reducing emissions, the National Assembly passed legislation for a carbon emissions trading program in 2012. Following an extensive policy development phase, which encountered significant opposition from the industrial sector, the program officially commenced on January 1, 2015. It regulates industries across 23 subsectors in five categories, including power generation, steel, cement, petrochemicals, refining, energy, construction, and aviation (Oh et al., 2017). By 2017, the Korean Emissions Trading Scheme (K-ETS) encompassed nearly 592 companies and facility entities in South Korea, representing $68\%$ of the nation's total domestic carbon emissions (Howie et al., 2020).

The compliance tools of the K-ETS include the direct reduction of $\mathrm{CO}_{2}$ emissions and the purchase of emission allowances (Choi and Qi, 2019). Regulated entities make emission reduction decisions by examining the potential benefits of reducing emissions and receive allowances based on marginal abatement costs to achieve efficient carbon emission reduction. The K-ETS construction is divided into three phases, 2015–2017, 2018–2020, and 2021–2025. In the transition between phases, the allocation of allowances is transitioned from all free, to free allocation mainly supplemented by paid auctions, and the emission cap is gradually reduced and the proportion of auctions is gradually increased (not less than $10\%$ in the third phase). From the second phase onwards, market stabilization measures are implemented through the allocation committee to stabilize the carbon price when there are price anomalies or excess demand (Oh et al., 2017).

# 2.5. China emission trading scheme (C-ETS)

As the world's largest carbon emitter, China committed at the 2015 United Nations Climate Change Conference in Paris to reduce its carbon emissions to $60 - 65\%$ of 2005 levels by the end of 2030 (Xu and Salem, 2021). Between 2013 and 2016, China sequentially established eight pilot Emissions Trading Schemes (ETSs) in Shenzhen, Guangdong, Hubei, Chongqing, Beijing, Shanghai, Tianjin, and Fujian. These schemes encompass eight key industries, including electricity, steel, petrochemicals, building materials, chemicals, paper, aviation, and nonferrous metals (Wang et al., 2022a, 2022b). Each pilot ETS boasts a unique market design and operates independently, having significantly contributed to GHG emission reductions in enterprises across the pilot provinces and cities. Additionally, these pilots have facilitated the development of the system, cultivated expertise, garnered experience, and established a foundation for the creation of a national carbon market (Lu et al., 2023). Throughout this process, the government has implemented a series of measures to enhance the trading system's market liquidity, introduce punitive measures, and extend trading hours. It has progressively introduced carbon allowance auctions to increase market liquidity (Huang et al., 2022b). Regarding disciplinary measures, the Chinese government has instituted a "default disciplinary mechanism," which enforces compliance by publicizing a list of defaulting companies. As of September 30, 2021, the pilot carbon market has encompassed nearly 3000 key emitting entities, with a cumulative trading volume reaching 495 million tons of carbon dioxide equivalent, and a turnover of approximately $1.87 billion (Wu and Wang, 2022).

At the close of 2017, China's National Development and Reform Commission (NDRC) unveiled a national carbon emissions trading program. In September 2020, China explicitly outlined its ambitions to achieve "carbon peaking" by 2030 and "carbon neutrality" by 2060. On July 16, 2021, the national carbon market, known as the C-ETS, commenced operations. Encompassing approximately 4.5 billion tons of carbon dioxide emissions, the C-ETS accounts for half of China's total carbon dioxide emissions. This volume is tenfold the cumulative trading

volume of the pilot market over the preceding eight years, establishing the C-ETS as the largest carbon market globally (Tan et al., 2022). Transaction data indicate that, as of July 14, 2023, the cumulative volume of carbon emission allowances (CEAs) traded in the national carbon market reached 239.9 million tons, with a cumulative transaction value of approximately $1.546 billion.

# 2.6. The United Kingdom emission trading scheme (UK ETS)

The UK ETS emerged as a consequence of the UK's Brexit policy and officially commenced operations in May 2021. It encompasses energy-intensive industries, the power sector, and aviation within the UK, collectively responsible for approximately one-third of the UK's greenhouse gas emissions. To stabilize the market, the UK ETS incorporates a transitional auction reserve price and a cost-containment mechanism, enabling the UK ETS Administering Authority to intervene should prices exhibit sustained increases. The UK carbon market, initiated independently, builds upon Phase III of the EU carbon market. It employs a comprehensive setup divided into two allocation periods. The initial allocation period spans from 2021 to 2025, distributing a total of 736 million tons of $\mathrm{CO}_{2}$ -equivalent allowances. The subsequent period, covering 2026 to 2030, allocates 630 million tons of $\mathrm{CO}_{2}$ -equivalent allowances, intentionally set $5\%$ lower than the UK's notional share of the EU ETS's Phase IV. Furthermore, the UK is contemplating an expansion of its carbon market to include sectors beyond power, industry, and domestic aviation. It has expressed openness to establishing links with other trading systems, notably the EU carbon market.[4]

# 3. Method and data

One significant contribution of econometric techniques to market surveillance and policy formulation, particularly relevant to monetary policy and energy/climate investments, is their capacity to pinpoint financial market booms through accurate quantitative measures. These techniques not only facilitate ex-post detection but also embody predictive algorithms that provide early warning diagnostics. By harnessing real-time data for continuous assessment, these methods assist regulators in effectively monitoring markets, including those directly influencing energy policies and climate-related financial investments. The integration of econometric insights enables policymakers to adjust monetary strategies promptly, optimizing the balance between economic growth and environmental sustainability. Financial historians, such as Ferguson (2008), have underscored the tendency for historical economic patterns to recur due to lapses in human learning mechanisms. Consequently, leveraging econometric alerts as proactive early warning tools can be instrumental for both market participants and regulators, ensuring informed decision-making in the realms of monetary policy and sustainable energy investments. This approach underscores the critical role of econometric techniques in shaping policies that address the intricate dynamics between economic development, environmental preservation, and climate change mitigation.

This chapter commences with an exploration of the asset pricing equation and the ADF test, illuminating the detection of asset bubbles and their analytical rationale. It progresses to discuss the SADF test, introduced by Phillips and Yu (2011), and the GSADF test, proposed by Phillips et al. (2015), which offer efficient ex-post analyses for identifying singular and multiple time-series bubbles, respectively. Furthermore, this section delves into the LPPLS model, a market dynamics-based approach for bubble prediction via power law function estimation on asset prices. Lastly, the data selection for this study is outlined.

# 3.1. Asset pricing equation and ADF test

The bubble test in financial markets generally starts from the asset pricing equation, which is formulated as follows:

$$
P _ {t} = \sum_ {i = 0} ^ {\infty} \left(\frac {1}{1 + r _ {f}}\right) ^ {i} E _ {t} \left(D _ {t + \mathrm {i}} + U _ {t + \mathrm {i}}\right) + B _ {t} \tag {1}
$$

where $P_{t}$ is the price of the asset after dividend payments; $D_{t}$ is the dividend payout from the asset; $U_{t}$ is unobservable fundamentals; $B_{t}$ is the bubble component; and $r_{f}$ is the risk-free rate. An important assumption in the asset pricing equation is that $B_{t}$ has the submartingale property:

$$
E _ {t} \left(B _ {t + 1}\right) = \left(1 + r _ {f}\right) B _ {t}, \tag {2}
$$

which implies that $E_{t}(B_{t + 1}) > E_{t}(B_{t})$ holds.

As can be seen from Eq. (1), there are two components to asset prices, one being the market fundamentals component $(D_{t} + U_{t})$ , which is the discounted value of expected future assets. The other is the bubble component $B_{t}$ . In this case, the rational bubble is not a mispricing effect, but a fundamental component of asset prices. Despite the potential for bubbles, Eq. (2) rules out arbitrage opportunities. Under the assumption that dividend growth is less than $r_f$ , the market fundamentals component of asset prices converges. The bubble component, on the other hand, is non-stationary due to the sub-martingale property. The price of an asset may exceed its fundamental value as long as agents expect that they can sell the asset at a higher price in the future (Gürkaynak, 2008). The explanation given by Phillips et al. (2015) is that evidence of explosive behavior of asset prices can be used to infer the existence of a bubble when $D_{t}$ and $U_{t}$ are at most a first-order smooth series ( $I(0)$ or $I(1)$ ). While the asset pricing equation is not the only model to explain the phenomenon of bubbles, for example, financial booms may originate from mispricing relative to fundamentals caused by behavioral factors, or the fundamental value itself may be highly sensitive to changes in the discount rate, which may lead to price increases similar to the inflationary phase of a bubble (Phillips and Yu, 2011; Phillips et al., 2015). Regardless of its origins, explosive or slightly explosive behavior of asset prices is the main indicator of market booms during the inflationary phase of a bubble (Phillips and Magdalinos, 2007).

In empirical studies, bubble tests are often based on the right-tailed ADF unit root test, which has good test results and adaptability to higher-order lags (Phillips et al., 2011). The general regression equation for the ADF test is:

$$
\Delta \mathbf {y} _ {t} = \alpha + \beta \mathbf {y} _ {t - 1} + \sum_ {i = 1} ^ {m} \theta_ {i} \Delta \mathbf {y} _ {t - i} + r _ {t} + u _ {t} \tag {3}
$$

where $\Delta$ denotes the first-order difference; $\alpha$ is the drift term; $\beta$ is the regression coefficient to be estimated; $\sum_{i=1}^{m} \theta_i \Delta y_{t-i}$ is the difference lag term; $r_t$ is the time-trend term; and $u_t$ is the random perturbation term. The null hypothesis of the right-tailed ADF test is $\beta = 0$ and the alternative hypothesis is $\beta > 0$ . When the null hypothesis is rejected, the original price series is considered to be in a bubble during the investigation period.

# 3.2. SADF test

Phillips and Yu (2011) proposed the SADF test, which determines whether a bubble exists by repeated estimation of the right-tailed ADF test on a sequence of forward-expanded samples. The SADF test statistic is the sup value of the corresponding sequence of ADF statistics. For the sample interval [0,1] (expressed as fractions), the SADF test fixes the starting point of the test interval $(r_1 = 0)$ and the endpoint of the test interval $(r_2)$ varies between the minimum sample window $(r_0)$ and the full sample $(r_2 = 1)$ . That is, the window length $r_w$ extends from $r_0$ to 1.

The formula for the SADF test is defined as follows:

$$
S A D F \left(r _ {0}\right) = \sup  _ {r _ {2} \in \left[ r _ {0}, 1 \right]} \left\{A D F _ {0} ^ {r _ {2}} \right\} \tag {4}
$$

Phillips and Yu (2011) and Phillips et al. (2015) recommend a rule for selecting $r_0$ that is based on a lower bound of $1\%$ of the full sample and has satisfactory power performance in a large number of simulations. This rule for selecting $r_0$ has a simple functional form:

$$
r _ {0} = 0. 0 1 + \frac {1 . 8}{\sqrt {T}} \tag {5}
$$

where $T$ is the number of observations in the overall sample.

In practice, financial regulators care whether a time point $\tau$ is in the bubble phase of the overall trajectory. The data-stamping strategy given by the SADF test algorithm proposed by Phillips et al. (2011) is to perform a right-tailed recursive ADF test from the sample origin to the current time observation $\tau$ . The origin date of the bubble $(r_s)$ is defined as the first time-series observation for which the ADF statistic exceeds a critical value. The termination date of the bubble $(r_e)$ is the first timeseries observation in which the ADF statistic for $L_{T}$ -period following $r_s$ falls below the critical value. Phillips et al. (2011) impose the condition that the duration of the bubble's existence must exceed a certain threshold, e.g. $L_{T} = \ln(T)$ . This threshold helps to exclude transient anomalous fluctuations in the time series and can be adjusted according to the frequency of the data using a coefficient $\delta$ , which is generally specified as $\delta = 1$ . The data-stamping strategy of the SADF test algorithm is summarized as follows:

$$
r _ {s} = \inf  _ {r _ {2} \in \left[ r _ {0}, 1 \right]} \left\{r _ {2} \left| A D F _ {r _ {2}} > c v _ {r _ {2}} ^ {\beta_ {T}} \right. \right\} \text {a n d} \tag {6}
$$

$$
r _ {e} = \inf  _ {r _ {2} \in \left[ r _ {s} + \delta \ln (T), 1 \right]} \left\{r _ {2} \left| A D F _ {r _ {2}} <   c v _ {r _ {2}} ^ {\beta_ {T}} \right. \right\} \tag {7}
$$

where $c\nu_{r_2}^{\beta_T}$ is the $100(1 - \beta_T)\%$ critical value of the right-tailed ADF statistic based on data from the $[0,r_2]$ observation interval. The significance level $\beta_T$ depends on the sample size $T$ and is assumed to be $\beta_T\rightarrow 0$ as $T\to 0$ . In practice, $\beta_T$ can be fixed at some predetermined level, e.g., 0.05.

Phillips et al. (2015) pointed out that there are two main drawbacks to this data-stamping strategy. On the one hand, one or more bubble events may exist in the data interval, and the right-tailed ADF test over the full data interval loses its ability to test for multiple bubbles. The reason for this is that the right-tailed ADF recursive test is unable to eliminate the effect of the timing of earlier bubbles. On the other hand, similar to the earlier unit root and cointegration-based bubble tests (Diba and Grossman, 1988), it may lead to the discovery of pseudosmooth processes (Evans, 1991).

# 3.3. GSADF test

The challenge of detecting financial bubbles underscores the necessity for employing multiple bubble tests, for three primary reasons. Firstly, historical evidence substantiates the occurrence of multiple financial crises; Ahamed (2011) documented 60 distinct financial crises since the turn of the century, indicating that, over sufficiently extended periods, data often reveal the presence of multiple asset price bubbles. Secondly, pinpointing multiple bubbles poses a significantly greater challenge than identifying a singular bubble, due to the intricate nonlinear structures associated with the multiple breaks that give rise to the bubble phenomenon. These multiple breaks tend to diminish the discriminatory capacity of existing testing frameworks, potentially leading to inconsistent outcomes, as observed in the recursive test described by Phillips et al. (2011). Such reductions in testing power necessitate the development of novel methods that circumvent these limitations, thereby enhancing econometric dating accuracy. Thirdly,

within the realm of financial oversight, recognizing multiple bubbles is of paramount importance. The exigencies of financial supervision mandate econometric methodologies capable of addressing the complexities of multiple bubbles, thereby establishing a dependable early warning system to preempt market inflation. An optimal early warning system would ideally exhibit a low rate of false detections to prevent unwarranted policy interventions and a high rate of positive detections to guarantee the timely and efficacious enactment of policy measures.

To address the limitations of the SADF test in identifying multiple bubbles, Phillips et al. (2015) introduced the GSADF test method, complemented by a recursive backward regression technique for accurately timestamping the onset and conclusion of bubbles. Unlike the SADF test, which fixes the start of the recursion at the initial observation, the GSADF test allows for variation in the beginning and end of the recursion through a flexible window, enhancing sample coverage. This method represents a right-hand side double recursion test for unit roots. The innovative dating strategy is an ex-ante procedure that builds upon the Phillips et al. (2011) dating strategy by varying the starting point of real-time analysis, thereby ensuring consistent results in the presence of multiple bubbles.

The sample start point $r_1$ of GSADF test varies from 0 to $1 - r_0$ and extends forward from there to change the detection sample. For the start point $r_1$ , the termination point $r_2$ takes values ranging from $r_1 + r_0$ to 1. GSADF test does recursion by moving the start and end points of the samples forward at the same time. The SADF test statistic is obtained by taking the upper bound of each right-tailed ADF, and then the GSADF test statistic is obtained by taking the upper bound of a series of SADF test statistics. The formula for calculating the GSADF test statistic is defined as follows:

$$
G S A D F \left(r _ {0}\right) = \sup  _ {\substack {r _ {2} \in \left[ r _ {0}, 1 \right] \\ r _ {1} \in \left[ 0, r _ {2} - r _ {0} \right]}} \left\{A D F _ {r _ {1}} ^ {r _ {2}} \right\} \tag{8}
$$

Similar to the limiting theory of the SADF test statistic, the asymptotic GSADF test distribution depends on the minimum window size $r_0$ . In practice, $r_0$ needs to be chosen based on the total number of observations $T$ . If $T$ is small, $r_0$ needs to be large enough to ensure that there are enough observations to make a proper initial estimate. If $T$ is large, $r_0$ can be set to a smaller number so that the test does not miss any opportunity to detect early explosive events. The empirical $r_0$ given by Phillips et al. (2015) still obeys Eq. (5).

To improve the date-stamping strategy for the right-tailed recursive ADF test of SADF test, Phillips et al. (2015) proposed a double recursive testing procedure called backward sup ADF (BSADF) test. $BSADF_{r_2}(r_0)$ fixes the sample endpoints at $r_2$ and varies the starting point $r_1$ from 0 to $r_2 - r_0$ , and $BSADF_{r_2}(r_0)$ is the upper definitive bound in a series of ADFs. Similar to Phillips et al. (2011), the feasible range of $r_2$ itself is recursive from $r_0$ to 1. Under the new identification strategy, the potential bubble explosiveness of the process at the observation point $r_2$ is inferred based on the $BSADF_{r_2}(r_0)$ . The defined bubble origin date $r_s$ is the first-time observation when the $BSADF_{r_2}(r_0)$ statistic exceeds the critical value. The termination date $r_e$ of the bubble is computed as the first observation after $r_s$ when the $BSADF_{r_2}(r_0)$ statistic falls below the critical value. For the bubble to be defined, it is still assumed that its duration should exceed the minimum period denoted by $\delta \ln(T)$ . The calculation formulas for $r_s$ and $r_e$ are as follows:

$$
r _ {s} = \inf  _ {r _ {2} \in \left[ r _ {0}, 1 \right]} \left\{r _ {2} \left| B S A D F _ {r _ {2}} \left(r _ {0}\right) > s c v _ {r _ {2}} ^ {\beta_ {T}} \right. \right\} \text {a n d} \tag {9}
$$

$$
r _ {e} = \inf  _ {r _ {2} \in \left\{r _ {s} + \delta \ln (T), 1 \right\}} \left\{r _ {2} \left| B S A D F _ {r _ {2}} \left(r _ {0}\right) <   s c v _ {r _ {2}} ^ {\beta_ {T}} \right. \right\} \tag {10}
$$

where $scv_{r_2}^{\beta_T}$ is the $100(1 - \beta_T)\%$ critical value of the sup ADF statistic based on data from the $[0, r_2]$ observation interval.

The SADF test is based on repeating the ADF test for each $r_2 \in [r_0, 1]$ .

The GSADF test repeats the backward sup ADF test for each $r_2 \in [r_0, 1]$ and makes inferences based on the sup value of the sequence of BSADF test statistics $\{BSADF_{r_2}(r_0)\}_{r_2 \in [r_0, 1]}$ . Therefore, the SADF test and GSADF test statistics have a fixed value on the given full sample data and $r_0$ . In contrast, $BSADF_{r_2}(r_0)$ is a continuous curve varying with $r_2$ . The formula of SADF test and GSADF test can be respectively written as:

$$
S A D F \left(r _ {0}\right) = \sup  _ {r _ {2} \in \left[ r _ {0}, 1 \right]} \left\{A D F _ {r _ {2}} \right\} \text {a n d} \tag {11}
$$

$$
G S A D F \left(r _ {0}\right) = \sup  _ {r _ {2} \in \left[ r _ {0}, 1 \right]} \left\{B S A D F _ {r _ {2}} \left(r _ {0}\right) \right\} \tag {12}
$$

Compared to Phillips et al. (2011), the BSADF test provides more information and improves the detection of bubbles within a sample, and this method provides greater flexibility in detecting multiple bubbles. This is because the subsample that produces the maximum ADF statistic may be associated with any particular observation interval from the full sample. Importantly, the new date-stamping strategy can be used as an ex ante real-time date procedure, whereas the GSADF test is an ex-post statistic used to analyze the behavior of bubbles in a given dataset (Phillips et al., 2015).

# 3.4. LPPLS model

The LPPLS model suggests that there is a positive feedback effect among traders in the capital market and that the investment behavior of irrational individuals imitating each other creates a collective herd effect (Yao and Li, 2021). This leads to asset prices growing in a power law form under the market dynamics mechanism, which ultimately leads to the creation of bubbles (Zhang et al., 2016). Financial bubbles will show logarithmic periodic oscillations and shorter oscillation periods in price evolution until they burst when they reach a critical point $t_c$ . According to Johansen (2003), the equation of the LPPLS model is expressed as follows:

$$
\ln P _ {t} \approx A + B \left(t _ {c} - t\right) ^ {\beta} + C \left(t _ {c} - t\right) ^ {\beta} \cos [ \omega \ln \left(t _ {c} - t\right) + \phi ] \tag {13}
$$

where $\ln P_{t}$ is the asset price in logarithmic form at time $t$ , the choice of logarithmic form makes the frequency of oscillation constant; $t_{c}$ denotes the singularity of the change in the growth rate of the price, i.e., the critical time when the previous bubble ends and transitions to another state; $A = \ln P_{t_c}$ is the logarithmic asset price at time $t_{c}$ ; $B$ indicates the direction of price change, and when $B < 0$ , it is a positive bubble with upward acceleration, while when $B > 0$ , it is a negative bubble with downward acceleration (Yan et al., 2010); $\beta$ is a power index taking values between 0 and 1, reflecting the acceleration of price increases, which is determined by the ratio of rational to irrational investors; $A + B_0(t_c - t)^{\beta}$ is the power rate singular component, which characterizes the super-exponential growth and reflects the positive feedback mechanism of the bubble; $\omega$ is a positive phase parameter indicating the angular frequency of the bubble fluctuations, which value is less than $2\pi$ and is determined by the convergence of market trading views (Yao and Li, 2021); $C$ denotes the log-periodic oscillation amplitude, whose value range is $[-1,1]$ ; $\phi$ denotes the time scale of the oscillation and is the initial phase of the fluctuation (Li, 2017).

The parameter estimation for the LPPLS model often uses the two-step nonlinear least squares method proposed by Johansen et al. (2000). The relatively small sample and large number of parameters make the estimation of the LPPLS model quite difficult, and in order to reduce the computational complexity, the nonlinear parameter $\phi$ is eliminated by expanding Eq. (13) into Eq. (14) using the correction method proposed by Filimonov and Sornette (2013):

$$
\ln P _ {t} \approx A + B (t _ {c} - t) ^ {\beta} + C _ {1} (t _ {c} - t) ^ {\beta} \cos [ \omega \ln (t _ {c} - t) ] + C _ {2} (t _ {c} - t) ^ {\beta} \sin [ \omega \ln (t _ {c} - t) ] \tag {14}
$$

where $C_1 = C\cos \phi$ and $C_2 = C\sin \phi$

Further, with reference to Johansen et al. (2000), subordinating the 4 linear parameters $A, B, C_1, C_2$ and computing them from the estimated nonlinear parameters $t_c, \beta, \omega$ . This can reduce the number of free parameters and simplify the calculation. Rewrite Eq. (14) into the following Eq. (15):

$$
y _ {t} \approx A + B f _ {t} + C _ {1} g _ {t} + C _ {2} h _ {t} \tag {15}
$$

where $y_{t} = \ln P_{t}$ , $f_{t} = (t_{c} - t)^{\beta}$ , $g_{t} = (t_{c} - t)^{\beta}\cos [\omega \ln (t_{c} - t)]$ , and $h_{t} = C_{2}(t_{c} - t)^{\beta}\sin [\omega \ln (t_{c} - t)]$ . The linear parameters can be solved by the following equation:

$$
\left( \begin{array}{l} \sum_ {t = 1} ^ {N} y _ {t} \\ \sum_ {t = 1} ^ {N} y _ {t} f _ {t} \\ \sum_ {t = 1} ^ {N} y _ {t} g _ {t} \\ \sum_ {t = 1} ^ {N} y _ {t} h _ {t} \end{array} \right) = \left( \begin{array}{c c c c} N & \sum_ {t = 1} ^ {N} f _ {t} & \sum_ {t = 1} ^ {N} g _ {t} & \sum_ {t = 1} ^ {N} h _ {t} \\ \sum_ {t = 1} ^ {N} f _ {t} & \sum_ {t = 1} ^ {N} f _ {t} ^ {2} & \sum_ {t = 1} ^ {N} f _ {t} g _ {t} & \sum_ {t = 1} ^ {N} f _ {t} h _ {t} \\ \sum_ {t = 1} ^ {N} g _ {t} & \sum_ {t = 1} ^ {N} g f _ {t} & \sum_ {t = 1} ^ {N} g _ {t} ^ {2} & \sum_ {t = 1} ^ {N} g _ {t} h _ {t} \\ \sum_ {t = 1} ^ {N} h _ {t} & \sum_ {t = 1} ^ {N} h _ {t} f _ {t} & \sum_ {t = 1} ^ {N} h _ {t} g _ {t} & \sum_ {t = 1} ^ {N} h _ {t} ^ {2} \end{array} \right) \left( \begin{array}{c} A \\ B \\ C _ {1} \\ C _ {2} \end{array} \right) \tag {16}
$$

If Eq. (16) is rewritten in matrix form, we can derive:

$$
X ^ {\prime} y = \left(X ^ {\prime} X\right) b \tag {17}
$$

$$
\text {w h e r e} X = \left( \begin{array}{c c c c} 1 & f _ {1} & g _ {1} & h _ {1} \\ \vdots & \vdots & \vdots & \vdots \\ 1 & f _ {N} & g _ {N} & h _ {N} \end{array} \right),   y = \left( \begin{array}{c} y _ {1} \\ \vdots \\ y _ {N} \end{array} \right), \text {a n d} b = \left( \begin{array}{c} A \\ B \\ C _ {1} \\ C _ {2} \end{array} \right).
$$

Then we can estimate the four linear parameters by the ordinary least squares method:

$$
\widehat {b} = \left(X ^ {\prime} X\right) ^ {- 1} X ^ {\prime} y \tag {18}
$$

The selection of optimal values for the three remaining nonlinear parameters $t_c, \beta, \omega$ is generated from randomly selected candidates from a uniform distribution with pre-specified ranges. The prespecified ranges for each nonlinear parameter were derived from empirical evidence from previous foams as follows (Johansen and Sornette, 2010):

$$
\max  \left\{t _ {2} - 6 0, \frac {t _ {2} - 0 . 5}{t _ {2} - t _ {1}} \right\} <   t _ {c} <   \min  \left\{t _ {2} + 2 5 2, \frac {t _ {2} + 0 . 5}{t _ {2} - t _ {1}} \right\} \tag {19}
$$

$$
0 <   \beta <   1 \tag {20}
$$

$$
2 <   \omega <   1 5 \tag {21}
$$

where $t_1$ and $t_2$ are the start and end date stamps of the observation interval $[t_1, t_2]$ , respectively. These setups allow the log-periodic oscillations to be neither too fast (to avoid fitting noise) nor too slow.

Furthermore, the candidates $t_c, \beta, \omega$ generated in the above range (Eqs. (19)-(21)) will be used as starting values in the Levenberg-Marquardt nonlinear least squares algorithm. The final fit function obtained has a least square sum with respect to the observed values. In order to avoid the steepest descent or Newton's descent method from falling into local optima, the genetic algorithm (Jacobsson, 2009) and two/three-step maximum likelihood (ML) method (Fantazzini, 2010) are used to estimate the parameters of the LPPLS model. Without expanding on this in the interest of space, the relevant arguments can be found in Geraskin and Fantazzini (2020).

In order to visualize the detected bubbles, we denote the observation length of the detection interval $[t_1,t_2]$ as $m = t_{2} - t_{1} + 1$ and set an interval time $i$ . Next, LPPLS functions are fitted to $[t_1,t_2],[t_1 + i,t_2],[t_1 + 2i,t_2],\ldots ,[t_2 - i,t_2]$ , respectively, deriving a series of regression parameters. For example, when the default values are set as $m = 120$ and $i = 5$ , the above process will result in $24\widehat{B}$ , which is recorded as $\{\widehat{B}\}_{1}^{24}$ . In this study, the CQ-ETS is set as $m = 5$ and $i = 1$ ; the C-ETS is set

as $m = 50$ and $i = 2$ ; the UK ETS is set as $m = 120$ and $i = 3$ ; and all other ETSs are asset as $m = 120$ and $i = 5$ . The LPPLS is then visualized by transforming the predicted $\{\widehat{B}\}_{1}^{24}$ into bubble indicators. For the resulting $\{\widehat{B}\}_{1}^{24}$ , the number of $\widehat{B} < 0$ (positive bubbles) and $\widehat{B} > 0$ (negative bubbles) are first counted and denoted as $Card\{\widehat{B}|\widehat{B} > 0\}$ and $Card\{\widehat{B}|\widehat{B} < 0\}$ , respectively. Next, further filtering is performed according to the following criteria for the $\widehat{B} < 0$ and $\widehat{B} > 0$ groups:

$$
\frac {\widehat {\omega}}{2 \pi} \ln \frac {\widehat {t} _ {c} - t _ {1}}{\widehat {t} _ {c} - t _ {2}} > 2. 5 \tag {22}
$$

$$
\frac {m | \widehat {B} |}{\omega | \widehat {C} |} > 0. 5 \tag {23}
$$

When $\widehat{t}_c, \widehat{\beta}, \widehat{\omega}$ satisfied Eqs. (22)-(23), the filtered quantities for the two groups $\widehat{B} < 0$ and $\widehat{B} > 0$ are calculated. The bubble indicators of LPPLS are then defined as:

$$
\text {P o s b u b b l e} = \frac {\operatorname {C a r d} \left\{\widehat {B} \mid \widehat {B} <   0 ; \widehat {t} _ {c} , \widehat {\beta} , \widehat {\omega} \sim \operatorname {E q .} (2 4) - (2 5) \right\}}{\operatorname {C a r d} \left\{\widehat {B} \mid \widehat {B} <   0 \right\}} \tag {24}
$$

$$
\text {N e g b u b b l e} = \frac {\operatorname {C a r d} \left\{\widehat {B} \mid \widehat {B} > 0 ; \widehat {t} _ {c} , \widehat {\beta} , \widehat {\omega} \sim E q . (2 4) - (2 5) \right\}}{\operatorname {C a r d} \left\{\widehat {B} \mid \widehat {B} > 0 \right\}} \tag {25}
$$

The values of Posbubble and Negbubble both range from 0 to 1. Posbubble denotes the positive percentage bubble in the asset price $t_2$ , which quantifies the likelihood that prices will fall in the near future. On the other hand, Negbubble represents the negative percentage bubble in the asset price at $t_2$ , which quantifies the likelihood that prices will rise in the near future (Ito et al., 2022). By deriving the corresponding positive and negative bubble metrics for each period, the LPPLS implements visual graphs indicating the strength of positive and negative bubbles.

# 3.5. Data description

This study examines six significant Emissions Trading Schemes (ETSs) globally, including the EU ETS, NZ ETS, CQ ETS, K-ETS, C-ETS, and UK ETS, conducting a thorough analysis and comparison of their price bubbles. The carbon prices for the EU ETS are sourced from Datastream, those for the C-ETS are obtained from Wind, and the prices for the K-ETS, NZ ETS, CQ ETS, and UK ETS are gathered from the public Carbon Pricing Dashboard of the World Bank. The prices across all six carbon markets are standardized to United States dollars for uniformity. With the exception of the CQ ETS, which reports carbon prices on a quarterly basis, the other five schemes provide daily carbon prices based on closing values.

The sample period and descriptive statistics for each carbon price are consolidated in Table 1, with a line graph illustrating the overarching price trend presented in Fig. 1. It is evident that carbon prices across the

various ETSs have experienced substantial fluctuations over time. The carbon prices of the EU ETS, NZ ETS, CQ ETS, K-ETS, and C-ETS exhibit right-skewed distributions to varying extents, with the EU ETS displaying the most pronounced skewness (reaching 1.606); conversely, the carbon price of the UK ETS shows a slightly left-skewed distribution. Additionally, the carbon prices of the EU ETS, NZ ETS, CQ ETS, and C-ETS are characterized by spiky distributions, with those of the C-ETS and EU ETS being particularly acute (featuring kurtosis of 1.655 and 1.571, respectively); meanwhile, the carbon prices of the K-ETS and UK ETS demonstrate flatter distributions. Furthermore, there is a significant range in the volatility of carbon prices among individual ETSs. The coefficient of variation (CoV) for the carbon prices of the EU ETS, NZ ETS, CQ ETS, K-ETS, C-ETS, and UK ETS are $99.67\%$ , $82.09\%$ , $40.29\%$ , $36.07\%$ , $13.88\%$ , and $23.14\%$ , respectively. These non-normal distribution characteristics and the breadth of price variation observed in the carbon prices of the ETSs suggest a high likelihood of bubble behavior.

# 4. Empirical results and discussion

In this section, the study initially examines the presence of price bubbles in six carbon markets, namely the EU ETS, NZ ETS, CQ ETS, K-ETS, C-ETS, and UK ETS, utilizing the SADF and GSADF tests for hypothesis testing. Subsequently, it delves into the characteristics,

![](images/0e39a4124a24d088b05d260c15dcdce34f812a29ac8aa387d2da177dc7d3cdd9.jpg)  
Fig. 1. Line graph of trends for each ETS's carbon prices.

Notes: Fig. 1 showcases a line graph of carbon price trends for six different ETSs over an extended period, reflecting the price evolution in each system. The graph illustrates substantial fluctuations in carbon prices over time, with some ETSs showing significant volatility and others demonstrating more stable trends. The EU ETS's carbon prices show a pronounced rightward skew, implying a distribution with more frequent high-price outliers. Conversely, the UK ETS's prices exhibit a slight leftward skew, suggesting infrequent lower-price values. Carbon prices for the EU and C ETSs indicate spiky distributions, characterized by sharp peaks, reflecting the presence of extreme values. Variation in the coefficient of variation (CoV) signifies differing levels of relative volatility, with the EU ETS displaying the highest and the C-ETS the lowest.

Table 1 Descriptive statistics of the six carbon prices.   

<table><tr><td>ETS</td><td>Time window</td><td>N</td><td>Min</td><td>Max</td><td>Mean</td><td>Sd</td><td>CoV</td><td>Skewness</td><td>Kurtosis</td></tr><tr><td>EU ETS</td><td>2005/4/22–2023/12/8</td><td>4792</td><td>0.01</td><td>110.64</td><td>26.22</td><td>26.13</td><td>99.67%</td><td>1.606</td><td>1.571</td></tr><tr><td>NZ ETS</td><td>2009/3/9–2023/9/29</td><td>3601</td><td>1.22</td><td>57.52</td><td>16.67</td><td>13.68</td><td>82.09%</td><td>1.288</td><td>0.790</td></tr><tr><td>CQ ETS</td><td>2012/11/30–2023/11/30</td><td>45</td><td>10.09</td><td>38.73</td><td>17.67</td><td>7.12</td><td>40.29%</td><td>1.413</td><td>1.059</td></tr><tr><td>K-ETS</td><td>2015/1/12–2023/9/27</td><td>2148</td><td>5.46</td><td>34.87</td><td>18.32</td><td>6.61</td><td>36.07%</td><td>0.280</td><td>-0.443</td></tr><tr><td>C-ETS</td><td>2021/7/16–2023/11/2</td><td>557</td><td>41.46</td><td>81.67</td><td>57.19</td><td>7.94</td><td>13.88%</td><td>0.563</td><td>1.655</td></tr><tr><td>UK ETS</td><td>2021/5/19–2023/12/8</td><td>648</td><td>40.85</td><td>116.51</td><td>80.89</td><td>18.72</td><td>23.14%</td><td>-0.198</td><td>-0.996</td></tr></table>

Notes: The table records data over various time windows, with the EU ETS having the longest and most extensive dataset from 2005 to 2023, and the CQ ETS the shortest and least. There are significant differences in the minimum, maximum, and mean prices between the ETSs, indicating substantial variability in carbon pricing mechanisms across systems. Most carbon prices are right-skewed, particularly the EU ETS, suggesting that carbon price distributions are not symmetrical and tend to have a longer tail to the right. The EU and C ETS show high kurtosis values, implying a tendency toward extreme values or outliers compared to a normal distribution. The CoV indicates the level of relative variability in carbon prices, with the EU ETS exhibiting the highest volatility and the C-ETS the lowest.

inception, and conclusion of price bubbles in each ETS, employing two dating methods: the BSADF and the LPPLS. Lastly, the study offers a focused analysis of the underlying causes of price bubbles in each ETS, exploring their implications for monetary policy, energy investments, and climate-related financial strategies.

# 4.1. Existence of carbon price bubbles

The SADF and GSADF test critical values adopted in this study are generated using the Monte Carlo finite sample resampling scheme with 2000 replications. The results of the SADF and GSADF tests for the six ETSs are given in Table 2. Except for the SADF test on the C-ETS, which can reject the null hypothesis of a random walk in carbon prices at the $95\%$ significance level, the SADF tests for the other five ETSs reject this hypothesis at the $99\%$ significance level. This indicates a higher degree of statistical certainty in the non-random behavior of carbon prices across these ETSs compared to the C-ETS. Moreover, the GSADF test shows that the carbon prices of all six ETSs reject the original hypothesis that the carbon price is a random walk at the $99\%$ significance level. From the overall results, the GSADF test has a larger statistic and a smaller significance $p$ -value than the SADF test, and therefore has a higher testing efficiency.

The significant findings from the SADF and GSADF tests imply that carbon prices exhibit patterns and trends that could be indicative of speculative bubbles or market inefficiencies. For monetary policymakers, these findings suggest the need for vigilance and potentially incorporating carbon market stability considerations into monetary policy frameworks. Central banks and financial regulators might need to consider the impact of carbon pricing on inflation, financial stability, and the overall economic landscape, especially when planning for inflation targeting, interest rate setting, or macroprudential policies. For energy investors and companies, the tests' results highlight the importance of market timing and the risks associated with bubble dynamics in carbon markets. This knowledge can lead to more strategic decision-making regarding the timing of investments in low-carbon technologies and infrastructure. Companies may need to assess their exposure to carbon market volatility and consider risk mitigation strategies in their investment planning. Moreover, the detection of price bubbles can have profound implications for climate finance strategies. It can inform the structuring of green bonds, climate funds, and other financial

Table 2 Results of SADF and GSADF tests for individual ETS.   

<table><tr><td rowspan="2">ETS</td><td rowspan="2" colspan="2">Test Statistic</td><td colspan="3">Critical values</td></tr><tr><td>90%</td><td>95%</td><td>99%</td></tr><tr><td rowspan="2">EU ETS (2005–2023)</td><td>SADF</td><td>2.728***</td><td>1.361</td><td>1.644</td><td>2.126</td></tr><tr><td>GSADF</td><td>5.620***</td><td>2.339</td><td>2.593</td><td>2.985</td></tr><tr><td rowspan="2">NZ ETS (2009–2023)</td><td>SADF</td><td>6.468***</td><td>1.350</td><td>1.625</td><td>2.126</td></tr><tr><td>GSADF</td><td>6.481***</td><td>2.311</td><td>2.515</td><td>2.939</td></tr><tr><td rowspan="2">CQ ETS (2012–2023)</td><td>SADF</td><td>2.516***</td><td>0.804</td><td>1.139</td><td>1.862</td></tr><tr><td>GSADF</td><td>4.036***</td><td>1.427</td><td>1.766</td><td>2.450</td></tr><tr><td rowspan="2">K-ETS (2015–2023)</td><td>SADF</td><td>4.608***</td><td>1.348</td><td>1.632</td><td>2.117</td></tr><tr><td>GSADF</td><td>8.452***</td><td>2.230</td><td>2.438</td><td>2.928</td></tr><tr><td rowspan="2">C-ETS (2021–2023)</td><td>SADF</td><td>1.542**</td><td>1.240</td><td>1.524</td><td>2.061</td></tr><tr><td>GSADF</td><td>4.696***</td><td>1.979</td><td>2.223</td><td>2.656</td></tr><tr><td rowspan="2">UK ETS (2021–2023)</td><td>SADF</td><td>3.785***</td><td>1.260</td><td>1.528</td><td>2.071</td></tr><tr><td>GSADF</td><td>4.286***</td><td>2.026</td><td>2.256</td><td>2.649</td></tr></table>

Notes: Table 2 shows the results of SADF and GSADF tests for carbon prices in various ETSs. In SADF: Except for the C-ETS, where the random walk hypothesis is rejected at the $95\%$ confidence level, all other ETSs reject the random walk hypothesis at the $99\%$ confidence level. In GSADF: This test rejects the random walk hypothesis for all six ETSs at the $99\%$ confidence level, indicating patterns or trends in carbon prices that could be predictable. Critical values are the threshold values generated through the Monte Carlo method, beyond which the null hypothesis of a random walk is rejected. *, **, *** denote rejection of the null hypothesis of random walk at $10\%$ , $5\%$ , and $1\%$ significance levels, respectively.

instruments tied to carbon markets.

# 4.2. Duration of the carbon price bubbles

This section employs a dating strategy to ascertain the duration of price bubbles in carbon markets, utilizing both the BSADF method associated with the GSADF and the LPPLS model. Figs. 2 through 7 present the results of bubble duration detection for the EU ETS, NZ ETS, CQ ETS, K-ETS, C-ETS, and UK ETS, respectively. Subplot (a) of each figure depicts all potential bubbles as per the BSADF methodology, with the blue curve denoting the carbon price's GSADF value and the red curve indicating the critical value (CV) at the $95\%$ significance level. A surpassing of the red curve by the blue one signals the occurrence of a price bubble in the carbon price for the respective ETS during that period, using gray shading to mark the period when the bubble existed. Subplot (b) in each figure illustrates the fit of the natural log of carbon price according to the LPPLS model. Meanwhile, subplot (c) provides a visual representation of the LPPLS model's bubble indicators, where the black curve represents the carbon price in natural logarithm terms, the red line signifies a positive bubble, and the green line denotes a negative bubble. The minimum duration of the price bubble in this study is defined as $\ln(T)$ , therefore, the minimum bubble durations for the EU ETS, NZ ETS, CQ ETS, K-ETS, C-ETS, and UK ETS are established at 8 days, 8 days, 3 quarters, 7 days, 6 days, and 6 days, respectively. Bubble durations that meet or exceed these thresholds are consolidated and detailed in Table 3.

For the EU ETS, the BSADF test identified a total of 11 bubbles, each with a duration of at least 8 days, occurring in 2007 (2007/2/2-2007/3/6), 2016 (2016/2/3-2016/2/19; 2016/2/23-2016/3/4), 2018 (2018/3/7-2018/5/2; 2018/5/9-2018/6/14; 2018/7/18-2018/9/13), 2021 (2021/4/20-2021/7/20; 2021/7/26-2021/8/19; 2021/8/20-2021/10/19; 2021/10/20-2021/11/1), and 2022 (2021/11/2-2022/3/1). The LPPLS model detected four positive bubbles in the EU ETS occurring in 2008 (2008/6/2-2008/6/13), 2017 (2017/8/23-2017/9/1; 2017/9/5-2017/9/14), and 2018 (2018/3/16-2018/4/4) there are positive bubbles; while in 2006 (2006/11/14-2006/11/27; 2006/12/6-2006/12/27), 2007 (2007/1/24-2007/2/8; 2007/5/2-2007/6/4; 2007/7/2-2007/7/17), 2011 (2011/7/11-2011/7/21; 2011/12/2-2011/12/19), and 2022 (2022/9/20-2022/10/3) have negative bubbles. Notably, bubble activity within the EU ETS was particularly pronounced in 2018, 2021, and 2022. Creti and Joëts (2017) applied the GSADF method to detect eleven carbon price bubbles of ten days or fewer in the EU ETS from 2005 to 2014, noting an absence of price bubbles between 2012 and 2014—a finding that aligns with the results of this study. Wei et al. (2022) identified eight price bubbles in the EU ETS spanning from 2008 to 2019, with consistent occurrences from 2016 to 2019, specifically between January 6, 2016, and April 4, 2017, and from May 16, 2017, to April 11, 2019. While the findings of Wei et al. (2022) show some concurrence with the carbon price bubbles identified in this study for the years 2016 to 2018, this study does not confirm the presence of bubbles in 2019. Creti and Joëts (2017) clarified that the results of bubble detection using the GSADF method are notably sensitive to the length of the sample analyzed. The sample window for this study spans from April 22, 2005, to December 8, 2023, covering the first through fourth phases of the EU ETS. This extensive period facilitates a thorough examination of carbon price bubbles, offering fresh insights and a more expansive, dynamic perspective on their long-term trends.

The BSADF test detected 4 bubbles with durations of at least 8 days in the NZ ETS, with occurrences in 2016 (2016/3/9-2016/11/18), 2020 (2021/12/1-2021/3/17), 2021 (2021/6/8-2022/9/29), and 2022 (2022/10/28-2022/12/16). The LPPLS model identified five positive and four negative bubbles. The positive bubbles occurred in 2009 (2009/8/31-2009/9/25), 2015 (2015/11/24-2015/12/4), 2016 (2016/4/5-2016/4/19; 2016/6/15-2016/6/27), and 2018 (2018/1/12-2018/2/2). Negative bubbles were noted in 2012 (2012/1/16-2012/2/3; 2012/12/11-2012/12/21), 2019 (2019/5/22-2019/6/

![](images/61f36d26c75af0709b5cef98b18f228340cc5189da4f84ea1edd06816cf13783.jpg)  
(a) GSADF and CV plot

![](images/24d4ee7b5f104d495a35c13fcc91b1f89779e86c648c21d8f790bb4dc7f96a84.jpg)

(b) LPPLS model fit values   
(c) Bubble indicators of the LPPLS model   
Fig. 2. Bubble detection results of the EU ETS.   
![](images/7700772a4cee447eb89689d83179d9c509c3742421ed4bb7d33832f3414c8391.jpg)  
Notes: Fig. 2 delineates the temporal scope of carbon price bubbles within the EU ETS as identified via the BSADF and LPPLS methodologies. Subfigure 2(a) employs a gray palette to illustrate that the majority of bubbles pinpointed by the BSADF test predominantly cluster around the years 2018, 2021, and 2022. Subfigure 2(b) illustrates that the LPPLS model fitting the EU ETS carbon prices effectively captures significant price trend shifts, albeit with the singular omission of the structural price break at the culmination of the EU ETS's first phase in late 2007. Meanwhile, Subfigure 2(c) visualizes both the positive bubbles—primarily concentrated in 2008, 2017, and 2018—and the negative bubbles—clustered in 2006, 2007, 2011, and 2022—as discerned by the LPPLS analysis of EU ETS carbon prices.

14) and 2020 (2020/11/11-2020/12/2). Overall, the NZ ETS contains two carbon price bubbles with long durations, one from March to November 2016 and the other from June 2021 to December 2022. Wei et al. (2022) conducted an analysis of carbon price bubbles in the NZ ETS from March 9, 2009, to August 31, 2019, identifying a sustained carbon price bubble from May 26, 2017, to April 25, 2019. Our study extends the observation period to September 29, 2023, enabling a broader assessment. With the extended timeframe of our study, the carbon price bubble in the NZ ETS is notably concentrated in the years 2016, 2021, and 2022.

For the CQ ETS, the BSADF test pinpointed a single bubble persisting for four quarters, commencing and concluding on 8/31/2021 and 8/31/2022, respectively. On the other hand, the LPPLS model identified a point-value positive bubble on 2021/8/31 with an indicator value of 0.5 but did not produce an effective duration.

The BSADF test discerned four carbon price bubbles within the K-ETS with durations of at least seven days, occurring in 2016 (2016/2/22-2016-5/27), 2017 (2017/1/25-2017/2/10; 2017/11/14-2017/11/27), and 2019 (2019/12/6-2019/12/24). Conversely, the LPPLS model identified three instances each of positive and negative bubbles in the K-ETS. The positive bubbles transpired in 2018 (2018/11/26-2018/12/11; 2019/4/18-2019/4/26) and 2019 (2019/10/14-2019/10/28). Negative bubbles are concentrated in 2020 (2020/6/4-2020/6/25; 2020/8/3-2020/8/27), and 2022 (2022/11/22-2022/11/30). Overall, carbon price bubbles in the K-ETS are relatively scattered, with no extended bubbles observed; the most prolonged bubble was in 2016, enduring for over three months. Wei et al. (2022) concluded that there

were no carbon price bubbles in the K-ETS during 2018 and 2019. Consistent with these findings, our study also observes only a few carbon price bubbles of short duration in the K-ETS during the same period.

For the China Emissions Trading Scheme (C-ETS), the BSADF test indicates the presence of three bubbles, each with a duration of at least six days. These bubbles occurred in 2021–2022 (2021/12/28–2022/1/18) and 2023 (2023/8/4–2023/8/31; 2023/9/13–2023/11/1). Additionally, the LPPLS model identified a period of bubbling activity in 2023 (2023/8/3–2023/8/11). Xu and Salem (2021) revealed that among the eight regional ETSs in China, five exhibited no carbon price bubbles from 2013 to 2019, including the Beijing, Chongqing, Fujian, Shanghai, and Shenzhen ETSs. Only three carbon bubbles existed in the Guangdong ETS, two in the Tianjin ETS, and one in the Hubei ETS. Similarly, Wei et al. (2022) observed that between 2013 and 2018, only four carbon bubbles, each lasting less than three days, occurred in the Shenzhen ETS. These findings align with the results of this study, which confirms that the C-ETS remained free of carbon price bubbles until December 2021.

Finally, for the UK Emissions Trading Scheme (UK ETS) carbon price, the BSADF test has identified a bubble period lasting at least six days in 2021 (2021/9/24-2021/10/6). Meanwhile, the LPPLS model detected bubble periods in 2022 (2022/9/23-2022/10/3) and 2023 (2023/6/2-2023/6/9; 2023/922-2023/9/29).

A comprehensive comparison of carbon bubble identification results across the six Emissions Trading Schemes (ETSs) reveals distinct patterns: the EU ETS exhibits the highest number of carbon price bubbles, the NZ ETS features the longest durations of carbon price bubbles, and

![](images/2aeaf3da3894defe92afc4f302b06bc68924ba758327647c41e46432801125c4.jpg)  
(a) GSADF and CV plot

![](images/d090ece1e037f074af0d6436216145ac18e11655995b7941e9f8f8dda802e26b.jpg)

(b) LPPLS model fit values   
(c) Bubble indicators of the LPPLS model   
Fig. 3. Bubble detection results of the NZ ETS.   
![](images/4da2db0c5a1a1893283257daf463bcd275f49fa918066ae0cac3cf75dfd15940.jpg)  
Notes: Fig. 3 elucidates the durations of carbon price bubbles in the NZ ETS as detected by the BSADF and LPPLS methodologies. Subfigure 3(a) employs gray shading to indicate that the BSADF method identified two prolonged carbon price bubbles within the NZ ETS: the first spanning from March to November 2016, and the second from June 2021 to December 2022. Subfigure 3(b) highlights the efficacy of the LPPLS model's power rate function, grounded in market dynamics, in accurately modeling several significant upward and downward trends in the NZ ETS carbon price. Subfigure 3(c) delineates the distribution of carbon price bubbles within the NZ ETS as identified by the LPPLS model. It reveals that positive bubbles are predominantly concentrated in the years 2009, 2015, 2016, and 2018, whereas negative bubbles are clustered in 2012, 2019, and 2020.

the CQ ETS has experienced a bubble lasting four quarters. In contrast, the K-ETS and C-ETS have recorded a smaller number of carbon price bubbles, all of relatively shorter durations, while the UK ETS has almost no carbon price bubbles. The occurrence of bubbles varies significantly across ETSs, with the earliest recorded in the EU ETS during 2006–2008 and the most recent in the C-ETS market in the fourth quarter of 2023. Notably, 2021 and 2022 emerge as years with significant overlap in bubble activity across all ETSs, marking a period of pronounced carbon price volatility.

This study further outlines certain attributes of the BSADF and LPPLS methods in determining the duration of price bubbles. Notably, the BSADF method proves to be more efficient than the LPPLS model in bubble detection, with the identified bubbles typically exhibiting longer durations. In contrast, bubbles identified by the LPPLS model are more scattered, with a smaller proportion exceeding the established duration threshold. A distinctive advantage of the LPPLS model is its ability to identify both positive and negative bubbles, offering valuable insights into potential future trends of carbon prices.

The findings of bubble durations in various carbon markets carry substantial implications for monetary policy, energy investments, and climate-related financial strategies. Moreover, they reflect the interplay between regulatory actions, market reactions, and global events. Firstly, monetary authorities can glean from the frequency and duration of carbon price bubbles vital information about market volatility, which may influence inflation expectations and, consequently, monetary policy adjustments. For instance, a persistent bubble in the NZ ETS, lasting from March 2016 to May 2019, and again from July 2020 to February

2023, suggests underlying market instabilities that could affect energy pricing and inflation rates. Such insights assist in the crafting of monetary policies that accommodate the cyclical nature of energy markets and the environmental goals tied to carbon pricing. Secondly, the results underline the necessity for investors in energy markets to be mindful of price volatility when planning investments. For example, the dispersion of bubbles in the K-ETS, with no long-term bubbles, suggests a more stable investment climate, whereas the EU ETS's concentration of bubbles in 2018, 2021, and 2022 might call for more cautious investment strategies during those periods. Thirdly, the identification of bubbles can help refine strategies for financing climate initiatives. The BSADF and LPPLS methods provide a temporal map of market sentiment, which is essential for pricing climate-related financial products, such as green bonds, and assessing the risks of investments in carbon-intensive industries. In the end, the periods of detected bubbles often align with significant policy announcements, regulatory changes, or economic events. For example, the EU ETS bubbles in 2021 and 2022 could correspond with the European Green Deal and the Fit for 55 package announcements. The ETSs' experiences in 2021 and 2022, where all ETSs faced significant bubble periods, may be linked to the economic recovery post-COVID-19 and the global drive for green energy investments. At the same time, events such as the adoption of the Paris Agreement, regulatory changes in major economies, or shifts in energy policy due to new government mandates could all have a bearing on the observed price fluctuations. It's crucial for stakeholders to align these econometric insights with real-world events to fully grasp the factors driving carbon market behavior and to enhance the resilience and

![](images/93976ae0d53853d18d146425ef61671ed004085291e6036f39b7e1e2d9971190.jpg)  
(a) GSADF and CV plot

![](images/e2623e6bd586f1cc28dcd2f1b67a5662f769c85be4a76b721842e9c5685c3fba.jpg)

(b) LPPLS model fit values   
(c) Bubble indicators of the LPPLS model   
Fig. 4. Bubble detection results of the CQ ETS.   
![](images/6479728ac684471828e4b4cf0da25c50787af863202960b9fbe0357317e04144.jpg)  
Notes: Fig. 4 presents the analysis of carbon price bubbles in the CQ ETS as identified by the BSADF and LPPLS methodologies. Subfigure 4(a) employs gray shading to highlight a bubble detected by the BSADF test that begins on August 31, 2021, lasting through to August 31, 2022. Additionally, two potential carbon price bubbles, each lasting less than three quarters, were identified. The first occurred from August 31, 2017, to February 28, 2018, and the second from May 31, 2019, to August 31, 2019. Subfigure 4(b) illustrates that the LPPLS model adeptly captures the exponential upward trend in the CQ ETS carbon price during the examined period. Subfigure 4(c) demonstrates that the LPPLS model pinpointed a point-positive bubble in the CQ ETS carbon price on August 31, 2021. However, this bubble did not persist beyond the specified duration, indicating a brief anomaly within the pricing trend.

effectiveness of policy measures and investment strategies in the face of such volatility.

In a nutshell, this study reveals that while the duration of bubbles varies across ETSs, the overlapping high bubble period across all ETSs in 2021 and 2022 is noteworthy. Such concurrent occurrences point to systemic factors affecting global carbon markets and necessitate coordinated policy responses. The BSADF test's efficiency over the LPPLS in detecting longer-duration bubbles could indicate more sustained market mispricings, requiring regulatory attention. In contrast, the LPPLS model's detection of both positive and negative bubbles offers foresight on potential market corrections, guiding timely interventions. The findings suggest that monetary policy, energy investments, and climate finance strategies must be adaptable to the dynamics of carbon markets. As markets continue to evolve, these econometric tools will be pivotal in navigating the complex landscape of carbon pricing and maintaining the delicate balance between economic growth, environmental sustainability, and financial stability.

# 4.3. Driving factors of the carbon price bubbles

This study identifies the primary drivers of carbon price bubbles across ETSs as the operating mechanisms and policies of carbon markets, the macroeconomic environment, fluctuations in energy prices, and market uncertainty.

Firstly, the mechanisms and policies governing carbon markets significantly influence carbon prices, causing pronounced fluctuations and potential bubbles by directly impacting carbon emissions' supply.

For instance, the allocation of carbon allowances under the National Allocation Plan (NAP) during Phase I of the EU ETS resulted in a substantial surplus of allowances (Alberola et al., 2008), triggering carbon price bubbles in 2007. Conversely, the introduction of an auction mechanism in Phase II of the EU ETS effectively mitigated price volatility, leading to fewer bubble events between 2008 and 2012. The ongoing reduction of carbon allowances in Phase III of the EU ETS, coupled with the initiation and implementation of the Market Stability Reserve (MSR) scheme, has continued to influence the supply side. This resulted in the transfer of 900 million tonnes of surplus carbon allowances to the reserve market from 2014 to 2016 (Huang et al., 2022a), precipitating frequent price bubbles in 2018. The EU's ambitious "Fit for 55" package, proposed on July 14, 2021, aims to overhaul the EU's climate policy framework comprehensively and fulfill the EU's pledge to reduce carbon emissions by $55\%$ by 2030 relative to 1990 levels. This initiative has induced significant price volatility in the carbon market, as evidenced by the bubbles occurring in the 2021/7/26-2021/8/19, 2021/8/20-2021/10/19, 2021/10/20-2021/11/1.

The NZ ETS functioned as a nested mechanism under the Kyoto Protocol until June 2015. During this phase, carbon prices within the NZ ETS were consistently lower than those in the secondary market for Certified Emission Reductions (CERs), which influenced the EU ETS pricing. Consequently, from 2009 to May 2015, the NZ ETS experienced minimal price bubble activity. However, with the transition of the NZ ETS into an independent system, successive long-term price bubbles began to emerge. This shift led to a rise in domestic prices, fueled by market speculation regarding future supply constraints (Leining et al.,

![](images/51d556deff21d6794a5bed8d6197b1113741e681c534ac71c439f6eaacb83616.jpg)  
(a) GSADF and CV plot

![](images/97e2c1abc97280404c6da0043fede3ea8c5432265982cdd18ed4729fb65a1bf7.jpg)

(b) LPPLS model fit values   
(c) Bubble indicators of the LPPLS model   
Fig. 5. Bubble detection results of the K-ETS.   
![](images/a81e8da172d87957893d62d44ede6c93b88bb8614c1cb8a180e1269f0f7854d4.jpg)  
Notes: Fig. 5 illustrates the durations of carbon price bubbles in the K-ETS as detected by the BSADF and LPPLS methodologies. Subfigure 5(a) uses gray shading to indicate that the BSADF identified a significant bubble spanning from February to May 2016, lasting over three months. Additionally, it detected shorter-lived bubbles in 2017 and 2019. Subfigure 5(b) shows that the LPPLS model effectively captures the upward convex price trend in the K-ETS, overall presenting an inverted U-shape. Subfigure 5(c) highlights that the LPPLS model recognizes dense positive bubbles in 2018 and 2019, and clusters of negative bubbles in 2020 and 2022.

2020). Additionally, the transition of the forestry sector from receiving one New Zealand Unit (NZU) per every two tons of carbon emissions to a one-for-one basis in 2017, coupled with governmental announcements that the NZ$25 fixed-price option would be altered post-2020, stimulated bubble formation after 2018. By the end of 2019, with the enactment of the Zero Carbon Act and the Climate Change Response (Emissions Trading Reform) Amendment Bill, the NZ ETS introduced measures such as capped auctions, restrictions on purchasing overseas units, replacement of the fixed-price option with new cost-control reserve options, an increase in auction reserve prices, and enhancements in forestry allocations. These measures have significantly contributed to the sustained growth of the NZ ETS carbon price bubble from late 2020 through the end of 2022.

For the California-Québec ETS (CQ ETS), Korean ETS (K-ETS), China ETS (C-ETS), and UK ETS, the occurrence and durations of price bubbles are relatively minor. On October 24 and 26, 2021, China's State Council released consecutive guidance programs on carbon peaking actions targeted for 2030. These programs provided a comprehensive framework for emission reduction across various sectors and industries, which aligns with the occurrence of price bubbles in the C-ETS within 2021/12/28–2022/1/18 timeframe. The price bubble observed in the K-ETS from 2017 to 2020 can be attributed to several key regulatory changes, including an increase in the auction ratio, a reduction in the allowance cap, and the implementation of market stabilization measures (Oh et al., 2017). These adjustments likely influenced market dynamics by altering supply and demand balances, thereby contributing to the observed fluctuations in carbon prices during this period.

Secondly, the macroeconomic environment significantly impacts the demand for carbon emissions by influencing the intensity of industrial activities, which, in turn, can lead to carbon price bubbles. For instance, the EU ETS experienced a price bubble in 2008 coinciding with the outbreak of the global financial crisis. Similarly, the bubbles occurring in 2011/7/11-2011/7/21 and 2011/12/2-2011/12/19, corresponded with the onset of the European debt crisis. During the post-COVID-19 period of 2021 and 2022, as the economies of various countries gradually recovered, the favorable macroeconomic environment contributed to the emergence of significant bubbles in the EU ETS, NZ ETS, CQ ETS, C-ETS, and UK ETS.

Thirdly, given that the combustion of fossil fuels accounts for approximately $75\%$ of total $\mathrm{CO}_{2}$ emissions (Hammoudeh et al., 2014), fluctuations in energy prices can significantly influence carbon prices and induce price bubbles by affecting $\mathrm{CO}_{2}$ emissions. For instance, in 2021, a pronounced imbalance between supply and demand was observed within the EU ETS carbon allowances market. On one side, the total quantity of EU allowances available on the supply side fell markedly below institutional requirements. On the other side, the European energy crisis, characterized by a sharp increase in natural gas prices and extreme weather conditions, led to a heightened reliance on coal, a high-carbon-emitting energy source. Given that coal produces roughly twice as much $\mathrm{CO}_{2}$ as natural gas, this shift precipitated a notable surge in demand for carbon allowances within the EU. Consequently, the price of EU Allowance (EUA) futures soared from $41.264 per tonne at the start of the year to$ 91.683 per tonne by year-end, marking an increase of $122.186\%$ . This dramatic price escalation fostered a sustained price

![](images/c01b835ef1d72379f792d705c17f056420d913011ab55b9d0226f7d12d0e960c.jpg)  
(a) GSADF and CV plot

![](images/edb98383a6fcaab4615f0aa42eaa6eb995c2c1f2713f1df1d6796ed964327277.jpg)  
(b) LPPLS model fit values

(c) Bubble indicators of the LPPLS model   
Fig. 6. Bubble detection results of the C-ETS.   
![](images/c64aac747aeab11557e5edf67cef3e982a241aba87a7c9df714cc1cbbd3ff06d.jpg)  
Notes: Fig. 6 elucidates the duration of carbon price bubbles in the C-ETS as identified by the BSADF and LPPLS methodologies. Subfigure 6(a) employs gray shading to reveal that the BSADF method detected a concentration of carbon price bubbles from late 2021 to early 2022, and again from August to October 2023. Subfigure 6 (b) demonstrates that the LPPLS model effectively captures the overall trend in C-ETS carbon prices, with a notably better fit observed in the second half of the period, after October 2022, compared to the first half. Subfigure 6(c) details that both positive and negative bubbles identified by the LPPLS model are widely scattered and correspond to minimal values on the bubble indicator, with only the positive bubbles spanning from August 3 to August 11, 2023, surpassing the 6-day duration threshold.

bubble in the EU ETS from April 2021 through to the end of the year.

Fourthly, market uncertainty contributes to the formation of price bubbles through mechanisms that influence the behavior of market participants. Uncertainty regarding future carbon pricing mechanisms and regulatory shifts can foster negative sentiment among investors, while doubts about the direction of carbon market policies may undermine market confidence. Developments in international climate agreements and geopolitical events can either instill uncertainty or boost confidence in the carbon market, significantly impacting market dynamics. During this period, oil prices experienced considerable fluctuations due to geopolitical tensions and concerns about oil supply disruptions. As industries grappled with rising production costs, the demand for carbon allowances surged to compensate for these expenses. On February 24, 2022, the outbreak of the Russian-Ukrainian conflict led to the emergence of a price bubble in the EU ETS, spanning from 2022/2/25 to 2022/3/1.

This study's findings offer deep insights into the nature and characteristics of green finance and sustainable finance, shedding light on the inherent risks for investors and drawing connections with behavioral finance theories. Firstly, the direct impact of carbon market operating mechanisms and policies on carbon prices highlights the critical role of regulatory frameworks in shaping the sustainability of green finance. The transition from surplus allowance allocation to auction mechanisms in the EU ETS demonstrates how policy adjustments can either create or mitigate price volatility, thereby influencing the stability and predictability of green finance markets. Secondly, the sensitivity of carbon

prices to the macroeconomic environment, as evidenced by the correlation between industrial activity intensity and carbon price bubbles, signals the need for green finance strategies to be resilient to broader economic fluctuations. The impact of global financial crises and regional economic downturns on carbon markets suggests that sustainable finance instruments must incorporate risk management strategies that account for economic cycles. Thirdly, investors in green and sustainable finance face several risks tied to policy changes, macroeconomic fluctuations, energy price volatility, and market uncertainty. The dynamic nature of carbon markets, influenced by regulatory shifts and external economic factors, requires investors to be vigilant and adaptable. In the end, the occurrence of carbon price bubbles, driven by speculative behavior in the face of uncertainty and external shocks, illustrates the impact of investor sentiment and herd behavior on market dynamics.

# 5. Conclusions

This study conducted a comprehensive examination and comparison of carbon price bubbles across six significant ETSs globally, including the EU ETS, NZ ETS, CQ ETS, K-ETS, C-ETS, and UK ETS, utilizing the SADF test, GSADF test, and LPPLS model. Distinguished from existing literature in the realm of carbon price bubble identification, this research encompasses the broadest array of markets, spans the most extended observation period, and employs the most diverse methodology for bubble analysis. By delving into the characteristics and underlying causes of carbon price bubbles within these six ETSs, this study

![](images/c7566a1a4d8b90bb957a92e1d9c9bf3810b5c46f5ab9b5dadf0909be0d0c89af.jpg)  
(a) GSADF and CV plot

![](images/8db62133f37ccedf867813220aed4bddcc06a5ebcc7bb65d28f0f72dfd855053.jpg)

![](images/fe192849c50139488004369794f04d06a8458353b42d89f793c9b0586b2a8168.jpg)  
(b) LPPLS model fit values   
(c) Bubble indicators of the LPPLS model   
Fig. 7. Bubble detection results of the UK ETS.   
Notes: Fig. 7 delineates the durations of carbon price bubbles in the UK ETS as determined by the BSADF and LPPLS methods. Subfigure 7(a) uses gray shading to highlight that the BSADF identified a brief bubble in the UK ETS carbon price spanning from September 24, 2021, to October 6, 2021. Subfigure 7(b) illustrates that the LPPLS model effectively captures an inverted U-shaped trend in the UK ETS carbon price. Subfigure 7(c) reveals that the LPPLS model identifies several scattered and short-lived negative bubbles in the UK ETS carbon price throughout 2022 and 2023, with the bubble indicator values being relatively small.

aims to offer insightful forecasts that enable compliance firms to meet their emission reduction objectives at minimal costs, assist governments in devising policies that accurately reflect the marginal costs of carbon emission reduction, and guide investors in refining their portfolio strategies and risk management practices.

The empirical analysis conducted in this study yields several noteworthy findings. Firstly, the EU ETS records the highest number of carbon price bubbles, the NZ ETS features the longest bubble durations, the CQ ETS experiences bubbles spanning four consecutive quarters, while the K-ETS and C-ETS exhibit fewer and shorter-lived carbon price bubbles, and the UK ETS displays almost no instances of carbon price bubbles. Secondly, a pronounced overlap in bubble activity across the ETSs is observed in 2021 and 2022, with all six ETSs undergoing significant carbon price bubble phases during these years. This phenomenon is likely attributable to the economic resurgence following the COVID-19 pandemic and prevailing market uncertainties amid geopolitical tensions. Thirdly, the emergence of carbon price bubbles within the six ETSs can be attributed to the operating mechanisms and policies of carbon markets, the macroeconomic climate, fluctuations in energy prices, and prevailing market uncertainties. In the end, the GSADF test outperforms the SADF in terms of efficiency in detecting bubbles. Additionally, bubbles identified by the BSADF method tend to have a longer duration, whereas those detected by the LPPLS model are more scattered and tend to be shorter.

The detection of price bubbles across various ETSs underscores inherent challenges within carbon market operations and regulatory frameworks. Drawing from empirical findings, this study advances targeted recommendations for three primary stakeholders: compliance

entities, governments, and investors. Firstly, for compliance entities, the study advocates for the adoption of dynamic emission reduction strategies attuned to market fluctuations. Recognizing the disparate nature of carbon price bubbles across ETSs, it is essential for these firms to employ adaptive strategies that are bespoke to the specific market dynamics they navigate. Particularly in ETSs prone to frequent bubbles, such as the EU ETS and NZ ETS, firms could benefit substantially from flexible emission reduction plans that accommodate market volatility, thereby enhancing cost-effectiveness and operational resilience. Secondly, governments are urged to cultivate carbon pricing policies that dynamically reflect market realities. This entails a periodic review and adjustment of emissions caps or allowance allocations grounded in empirical data analysis. Leveraging insights from carbon price bubble trends enables policymakers to synchronize carbon pricing more closely with market conditions, ensuring that carbon emission reduction efforts align with true marginal costs. Such a strategy not only augments market efficiency but also mitigates the risk of distortions arising from persistent bubbles, directly influencing monetary policy by stabilizing market-driven incentives for green investment. Thirdly, investors are encouraged to integrate an understanding of carbon market dynamics into their investment frameworks, especially during periods characterized by price bubbles. An acute awareness of the macroeconomic landscape, energy price shifts, and geopolitical developments is crucial for informed decision-making. Diversifying investments across various ETSs and calibrating investment exposure to address market uncertainties can bolster portfolio resilience. Moreover, effective risk management practices must account for the potential influence of carbon price volatility on investment outcomes, guiding energy and climate-related financial

Table 3 Carbon price bubbles duration of individual ETS.   

<table><tr><td rowspan="2">ETS</td><td rowspan="2">BSADF</td><td colspan="2">LPPLS</td></tr><tr><td>Positive bubble</td><td>Negative bubble</td></tr><tr><td>EU</td><td>(1) 2007/2/2-2007/3/6;</td><td>(1) 2008/6/2-2008/6/13;</td><td>(1) 2006/11/14-2006/11/27;</td></tr><tr><td>ETS</td><td>(2) 2016/2/3-2016/2/19;</td><td>(2) 2017/8/23-2017/9/1;</td><td>(2) 2006/12/6-2006/12/27;</td></tr><tr><td></td><td>(3) 2016/2/23-2016/3/4;</td><td>(3) 2017/9/5-2017/9/14;</td><td>(3) 2007/1/24-2007/2/8;</td></tr><tr><td></td><td>(4) 2018/3/7-2018/5/2;</td><td>(4) 2018/3/16-2018/4/4</td><td>(4) 2007/5/2-2007/6/4;</td></tr><tr><td></td><td>(5) 2018/5/9-2018/6/14;</td><td></td><td>(5) 2007/7/2-2007/7/17;</td></tr><tr><td></td><td>(6) 2018/7/18-2018/9/13;</td><td></td><td>(6) 2011/7/11-2011/7/21;</td></tr><tr><td></td><td>(7) 2021/4/20-2021/7/20;</td><td></td><td>(7) 2011/12/2-2011/12/19;</td></tr><tr><td></td><td>(8) 2021/7/26-2021/8/19;</td><td></td><td>(8) 2022/9/20-2022/10/3</td></tr><tr><td></td><td>(9) 2021/8/20-2021/10/19;</td><td></td><td></td></tr><tr><td></td><td>(10) 2021/10/20-2021/11/1;</td><td></td><td></td></tr><tr><td></td><td>(11) 2021/11/2-2022/3/1</td><td></td><td></td></tr><tr><td>NZ</td><td>(1) 2016/3/9-2016/11/18;</td><td>(1) 2009/8/31-2009/9/25;</td><td>(1) 2012/1/16-2012/2/3;</td></tr><tr><td>ETS</td><td>(2) 2020/12/1-2021/3/17;</td><td>(2) 2015/11/24-2015/12/4;</td><td>(2) 2012/12/11-2012/12/21;</td></tr><tr><td></td><td>(3) 2021/6/8-2022/9/29;</td><td>(3) 2016/4/5-2016/4/19;</td><td>(3) 2019/5/22-2019/6/14;</td></tr><tr><td></td><td>(4) 2022/10/28-2022/12/16</td><td>(4) 2016/6/15-2016/6/27;</td><td>(4) 2020/11/11-2020/12/2</td></tr><tr><td></td><td></td><td>(5) 2018/1/12-2018/2/2</td><td></td></tr><tr><td>CQ</td><td>(1) 2021/8/31-2022/8/31</td><td></td><td></td></tr><tr><td>ETS</td><td>(1) 2016/2/22-2016/5/27;</td><td>(1) 2018/11/26-2018/12/11;</td><td>(1) 2020/6/4-2020/6/25;</td></tr><tr><td></td><td>(2) 2017/1/25-2017/2/10;</td><td>(2) 2019/4/18-2019/4/26;</td><td>(2) 2020/8/3-2020/8/27;</td></tr><tr><td></td><td>(3) 2017/11/14-2017/11/27;</td><td>(3) 2019/10/14-2019/10/28</td><td>(3) 2022/11/22-2022/11/30</td></tr><tr><td></td><td>(4) 2019/12/6-2019/12/24</td><td></td><td></td></tr><tr><td>K-ETS</td><td>(1) 2021/12/28-2022/1/18;</td><td>(1) 2023/8/3-2023/8/11</td><td></td></tr><tr><td></td><td>(2) 2023/8/4-2023/8/31;</td><td></td><td></td></tr><tr><td></td><td>(3) 2023/9/13-2023/11/1</td><td></td><td></td></tr><tr><td>UK</td><td>(1) 2021/9/24-2021/10/6</td><td></td><td>(1) 2022/9/23-2022/10/3;</td></tr><tr><td>ETS</td><td></td><td></td><td>(2) 2023/6/2-2023/6/9;</td></tr><tr><td></td><td></td><td></td><td>(3) 2023/9/22-2023/9/29</td></tr></table>

Notes: Table 3 encapsulates the bubble durations for the carbon prices of the six distinct ETSs identified by the BSADF and LPPLS methods. This study sets the minimum bubble duration according to the $\ln (T)$ criterion for the EU ETS, NZ ETS, CQ ETS, K-ETS, C-ETS, and UK ETS, which are 8 days, 8 days, 3 quarters, 7 days, 6 days, and 6 days, respectively. Notably, the EU ETS exhibits the highest frequency of carbon price bubbles, the NZ ETS records the most extensive cumulative duration of these bubbles, and the CQ ETS experiences a year-long carbon price bubble. In stark contrast, both the K-ETS and C-ETS are characterized by fewer and shorter-lived carbon price bubbles, and the UK ETS displays a near absence of such carbon price bubbles.

strategies toward more sustainable and profitable ventures. In essence, this study not only elucidates the empirical nuances of carbon price bubbles within ETSs but also translates these insights into actionable intelligence for key market participants. By doing so, it bridges the gap between academic research and practical application, offering a valuable compass for navigating the complexities of monetary policy and

energy/climate investments in the evolving landscape of carbon markets.

# CRediT authorship contribution statement

Wenyang Huang: Funding acquisition, Writing - review & editing, Writing - original draft, Visualization, Validation, Software, Resources, Methodology, Investigation, Formal analysis, Data curation, Conceptualization. Yizhi Wang: Writing - review & editing, Writing - original draft, Visualization, Validation, Software, Resources, Project administration, Methodology, Investigation, Formal analysis, Data curation, Conceptualization.

# Declaration of competing interest

None.

# Acknowledgements

The authors are grateful for the financial support from the Beijing Natural Science Foundation (Grant No. 9244030), and the Postdoctoral Fellowship Program of CPSF.

# Appendix A. Supplementary data

Supplementary data to this article can be found online at https://doi.org/10.1016/j.eneco.2024.107626.

# References

Ahamed, L., 2011. Lords of Finance: The Bankers Who Broke the World. Random House.   
Alberola, E., Chevallier, J., Cheze, B., 2008. Price drivers and structural breaks in European carbon prices 2005-2007. Energy Policy 36 (2), 787-797.   
Bohringer, C., 2003. The Kyoto protocol: a review and perspectives. Oxf. Rev. Econ. Policy 19 (3), 451-466.   
Brander, M., Davis, G., 2012. Greenhouse Gases, CO2, CO2e, and Carbon: What Do all these Terms Mean. Econometrica, White Papers.   
Bullock, D., 2012. Emissions trading in New Zealand: development, challenges and design. Environ. Politics 21 (4), 657-675.   
Choi, Y., Qi, C., 2019. Is South Korea's emission trading scheme effective? An analysis based on the marginal abatement cost of coal-fueled power plants. Sustainability 11 (9), 2504.   
Creti, A., Joëts, M., 2017. Multiple bubbles in the European union emission trading scheme. Energy Policy 107, 119-130.   
Creti, A., Jouvet, P.A., Mignon, V., 2012. Carbon price drivers: phase I versus phase II equilibrium? Energy Econ. 34 (1), 327-334.   
De La Vega, E., Chalk, T.B., Wilson, P.A., et al., 2020. Atmospheric CO2 during the mid-piacenzian warm period and the M2 glaciation. Sci. Rep. 10 (1), 1-8.   
Diba, B.T., Grossman, H.I., 1987. On the inception of rational bubbles. Q. J. Econ. 102 (3), 697-700.   
Diba, B.T., Grossman, H.I., 1988. Explosive rational bubbles in stock prices? Am. Econ. Rev. 78 (3), 520-530.   
Engle, R.F., Granger, C.W.J., 1987. Co-integration and error correction: representation, estimation, and testing. Econometrica 251-276.   
Evans, G.W., 1991. Pitfalls in testing for explosive bubbles in asset prices. Am. Econ. Rev. 81 (4), 922-930.   
Fantazzini, D., 2010. Modeling bubbles and anti-bubbles in bear markets. TRADING 365.   
Ferguson, N., 2008. The Ascent of Money: A Financial History of the World. Penguin.   
Filimonov, V., Sornette, D., 2013. A stable and robust calibration scheme of the log-periodic power law model. Phys. A: Stat. Mech. Appl. 392 (17), 3698-3707.   
Froot, K.A., 1991. Obstfeld M. Intrinsic bubbles: the case of stock prices. Am. Econ. Rev. 81, 1189-1214.   
Geraskin, P., Fantazzini, D., 2020. Everything you always wanted to know about log-periodic power laws for bubble modeling but were afraid to ask. New Facets Econ. Complex. Modern Financ. Markets 30-55.   
Gonçalves, S., Kilian, L., 2004. Bootstrapping autoregressions with conditional heteroskedasticity of unknown form. J. Econ. 123 (1), 89-120.   
Gordon, H.B., Whetton, P.H., Pittock, A.B., et al., 1992. Simulated changes in daily rainfall intensity due to the enhanced greenhouse effect: implications for extreme rainfall events. Clim. Dyn. 8 (2), 83-102.   
Grobys, K., 2023. A finite-time singularity in the dynamics of the US equity market: will the US equity market eventually collapse? Int. Rev. Financ. Anal. 89, 102787.   
Gürkaynak, R.S., 2008. Econometric tests of asset price bubbles: taking stock. J. Econ. Surv. 22 (1), 166-186.   
Hammoudeh, S., Nguyen, D.K., Sousa, R.M., 2014. What explain the short-term dynamics of the prices of CO2 emissions? Energy Econ. 46, 122-135.

Hofmann, M., Schellnhuber, H.J., 2010. Ocean acidification: a millennial challenge. Energy Environ. Sci. 3 (12), 1883-1896.   
Houle, D., Lachapelle, E., Purdon, M., 2015. Comparative politics of sub-federal cap-and-trade: implementing the Western climate initiative. Global Environ. Politics 15 (3), 49-73.   
Howie, P., Gupta, S., Park, H., et al., 2020. Evaluating policy success of emissions trading schemes in emerging economies: comparing the experiences of Korea and Kazakhstan. Clim. Pol. 20 (5), 577-592.   
Huang, W., Wang, H., Qin, H., et al., 2022a. Convolutional neural network forecasting of European Union allowances futures using a novel unconstrained transformation method. Energy Econ. 110, 106049.   
Huang, W., Wang, Q., Li, H., et al., 2022b. Review of recent progress of emission trading policy in China. J. Clean. Prod. 349, 131480.   
Huang, W., Gao, T., Hao, Y., et al., 2023. Transformer-based forecasting for intraday trading in the Shanghai crude oil market: analyzing open-high-low-close prices. Energy Econ. 127, 107106.   
Huang, W., Zhao, J., Wang, X., 2024. Model-driven multimodal LSTM-CNN for unbiased structural forecasting of European Union allowances open-high-low-close price. Energy Econ. 132, 107459.   
Hyun, J., Oh, H., 2015. Korea's Emission Trading System: An Attempt of Non-Annex I Party Countries to Reduce GHG Emissions Voluntarily. Retrieved from February, 3, 2019.   
Ito, K., Shibano, K., Mogi, G., 2022. Bubble Prediction of Non-Fungible Tokens (NFTs): An Empirical Investigation. arXiv preprint. arXiv:2203.12587.   
Jacobsson, E., 2009. How to Predict Crashes in Financial Markets with the Log-Periodic Power Law. Master diss. Department of Mathematical Statistics, Stockholm University.   
Johansen, A., 2003. Characterization of large price variations in financial markets. Phys. A: Stat. Mech. Appl. 324 (1-2), 157-166.   
Johansen, A., Sornette, D., 2001. Finite-time singularity in the dynamics of the world population, economic and financial indices. Phys. A: Stat. Mech. Appl. 294 (3-4), 465-502.   
Johansen, A., Sornette, D., 2010. Shocks, crashes and bubbles in financial markets. Brussels Econ. Rev. 53 (2), 201-253.   
Johansen, A., Ledoit, O., Sornette, D., 2000. Crashes as critical points. Int. J. Theoretic. Appl. Financ. 3 (02), 219-255.   
Koch, N., Fuss, S., Grosjean, G., et al., 2014. Causes of the EU ETS price drop: recession, CDM, renewable policies or a bit of everything?—new evidence. Energy Policy 73, 676-685.   
Leining, C., Kerr, S., Bruce-Brand, B., 2020. The New Zealand emissions trading scheme: critical review and future outlook for three design innovations. Clim. Pol. 20 (2), 246-264.   
LeRoy, S.F., Porter, R.D., 1981. The present-value relation: tests based on implied variance bounds. Econometrica 555-574.   
Li, C., 2017. Log-periodic view on critical dates of the Chinese stock market bubbles. Phys. A: Stat. Mech. Appl. 465, 305-311.   
Lu, M., Wang, X., Speeckaert, R., 2023. Price bubbles in Beijing carbon market and environmental policy announcement. Commun. Stat. Simulat. Comp. 52 (3), 884-897.   
Lucas, R.E., 1978. Asset prices in an exchange economy. Econometrica 1429-1445.   
Mansonet-Bataller, M., Pardo, A., Valor, E., 2007. CO2 prices, energy and weather. Energy J. 28 (3).   
Mansanet-Bataller, M., Chevallier, J., Hervé-Mignucci, M., et al., 2010. The EUA-sCER spread: compliance strategies and arbitrage in the European carbon market, p. 2010.   
Mayer, J., 2012. The growing financialisation of commodity markets: divergences between index investors and money managers. J. Dev. Stud. 48 (6), 751-767.   
Mochizuki, J., 2011. Assessing the designs and effectiveness of Japan's emissions trading scheme. Clim. Pol. 11 (6), 1337-1349.   
Oberthur, S., Ott, H.E., 1999. The Kyoto Protocol: International Climate Policy for the 21st Century. Springer Science & Business Media.   
Oh, H., Hyon, J., Kim, J.O., 2017. Korea's approach to overcoming difficulties in adopting the emission trading scheme. Clim. Pol. 17 (8), 947-961.

Perino, G., 2018. New EU ETS phase 4 rules temporarily puncture waterbed. Nat. Clim. Chang. 8 (4), 262-264.   
Phillips, P.C.B., Magdalinos, T., 2007. Limit theory for moderate deviations from a unit root. J. Econ. 136 (1), 115-130.   
Phillips, P.C.B., Yu, J., 2011. Dating the timeline of financial bubbles during the subprime crisis. Quant. Econ. 2 (3), 455-491.   
Phillips, P.C.B., Wu, Y., Yu, J., 2011. Explosive behavior in the 1990s Nasdaq: when did exuberance escalate asset values? Int. Econ. Rev. 52 (1), 201-226.   
Phillips, P.C.B., Shi, S., Yu, J., 2015. Testing for multiple bubbles: historical episodes of exuberance and collapse in the S&P 500. Int. Econ. Rev. 56 (4), 1043-1078.   
Ranson, M., Stavins, R.N., 2016. Linkage of greenhouse gas emissions trading systems: learning from experience. Clim. Pol. 16 (3), 284-300.   
Riedl, D., 2022. Why market actors fuel the carbon bubble. The agency, governance, and incentive problems that distort corporate climate risk management. J. Sustain. Financ. Invest. 12 (2), 407-422.   
Sachan, N., Singh, V.P., 2010. Effect of climatic changes on the prevalence of zoonotic diseases. Vet. World 3 (11), 519.   
Song, Y., Liang, D., Liu, T., et al., 2018. How China's current carbon trading policy affects carbon price? An investigation of the Shanghai emission trading scheme pilot. J. Clean. Prod. 181, 374-384.   
Tan, X., Liu, Y., Dong, H., et al., 2022. The effect of carbon emission trading scheme on energy efficiency: evidence from China. Econ. Anal. Policy 75, 506-517.   
Tan, X.P., Wang, X.Y., 2017. Dependence changes between the carbon price and its fundamentals: A quantile regression approach. Appl. Energy 190, 306-325.   
Titus, J.G., 1986. Greenhouse effect, sea level rise, and coastal zone management. Coast. Manag. 14 (3), 147-171.   
Viteva, S., Veld-Merkoulova, Y.V., Campbell, K., 2014. The forecasting accuracy of implied volatility from ECX carbon options. Energy Econ. 45, 475-484.   
Wang, A., Carpenter-Gold, D., Shen, S., et al., 2022a. Emissions Trading in California: Lessons for China. Available at SSRN.   
Wang, X.Q., Su, C.W., Lobont, O.R., et al., 2022b. Is China's carbon trading market efficient? Evidence from emissions trading scheme pilots. Energy 245, 123240.   
Wei, Y., Li, Y., Wang, Z., 2022. Multiple price bubbles in global major emission trading schemes: Evidence from European Union, New Zealand, South Korea and China. Energy Econ. 113, 106232.   
Wei, Y., Liang, X., Xu, L., et al., 2023. Trading, storage, or penalty? Uncovering firms' decision-making behavior in the Shanghai emissions trading scheme: insights from agent-based modeling. Energy Econ. 117, 106463.   
West, K.D., 1987. A specification test for speculative bubbles. Q. J. Econ. 102 (3), 553-580.   
Wheatley, S., Sornette, D., Huber, T., et al., 2019. Are bitcoin bubbles predictable? Combining a generalized Metcalfe's law and the log-periodic power law singularity model. R. Soc. Open Sci. 6 (6), 180538.   
Wu, Y., 1997. Rational bubbles in the stock market: accounting for the US stock-price volatility. Econ. Inq. 35 (2), 309-319.   
Wu, Q., Wang, Y., 2022. How does carbon emission price stimulate enterprises' total factor productivity? Insights from China's emission trading scheme pilots. Energy Econ. 109, 105990.   
Xu, Y., Salem, S., 2021. Explosive behaviors in Chinese carbon markets: are there price bubbles in eight pilots? Renew. Sust. Energ. Rev. 145, 111089.   
Yan, J., 2021. The impact of climate policy on fossil fuel consumption: evidence from the regional greenhouse gas initiative (RGGI). Energy Econ. 100, 105333.   
Yan, W., Woodard, R., Sornette, D., 2010. Diagnosis and prediction of tipping points in financial markets: crashes and rebounds. Phys. Procedia 3 (5), 1641-1657.   
Yao, C.Z., Li, H.Y., 2021. A study on the bursting point of bitcoin based on the BSADF and LPPLS methods. North Am. J. Econ. Financ. 55, 101280.   
Zaklan, A., Wachsmuth, J., Duscha, V., 2021. The EU ETS to 2030 and beyond: adjusting the cap in light of the $1.5^{\circ}$ C target and current energy policies. Clim. Pol. 21 (6), 778-791.   
Zhang, Q., Zhang, Q., Sornette, D., 2016. Early warning signals of financial crises with multi-scale quantile regressions of log-periodic power law singularities. PLoS One 11 (11), e0165819.